# FreshCart capstone: team submission

Team: ____________________   Members and roles: ________________________________

## Task 1. Requirement review (REQ-FC-50 draft)

| # | AC | Problem type | What is wrong | Question for the product owner | Found by (AI, us, both) |
|---|----|--------------|---------------|--------------------------------|-------------------------|
| 1 |    |              |               |                                |                         |

Real problems the AI found: ___   AI rows that were not real problems: ___

## Task 2. Prompt template and scenarios

Template version and changes from v1.0: ______________________
Model and deployment used (or mock): ______________________
Score run 1: ___/20   Score run 2: ___/20   Boundaries still missing: ______________________
Invented content you removed: ______________________

## Task 3. Test data

Rows flagged: ___   Rule broken in each: ______________________
Boundaries with no row: ______________________

## Task 4. Automated tests

File: tests/test_fee_rules.py   Tests: ___   Pass on fees.py: yes / no
Fail on fees_buggy.py: ___ tests   The three bugs: 1. ________ 2. ________ 3. ________
Expected values taken from: ______________________

## Task 5. Nightly run triage

| Group | Tests | Category | Evidence | Next action |
|-------|-------|----------|----------|-------------|
|       |       |          |          |             |

Release recommendation (go or no-go, with the condition): ______________________
Signed by (a person): ____________________

## Task 6. Responsible AI review

| File | Problem | Category (WRONG, INVENTED, UNSAFE, DATA, INJECTED, WEAK) | Found by (READ, TEST, SCAN) |
|------|---------|-----------------------------------------------------------|-----------------------------|
|      |         |                                                           |                             |

Hardening you would apply to review triage: ______________________

## Task 7. Next AI use case (canvas summary)

Use case: ______________   Success measure: ______________   Human check: ______________
First step, owner and date: ______________

## What we used AI for, and what we checked ourselves

______________________
