"""FreshCart fee rules D1 to D9 in code (see docs/fee_rules.md)."""
from decimal import Decimal


def calculate_fees(subtotal, member=False, express=False, rain=False, order_time="14:00"):
    """Return a dict of fee lines and the total. subtotal in INR; order_time is 'HH:MM' (24-hour)."""
    sub = Decimal(str(subtotal))
    if sub < 0:
        raise ValueError("subtotal must not be negative")
    fees = {}
    free_from = Decimal(199) if member else Decimal(499)                     # D2, D4
    if sub < 199:
        fees["delivery"] = Decimal(30)
    elif sub < free_from:
        fees["delivery"] = Decimal(20)
    else:
        fees["delivery"] = Decimal(0)
    fees["small_cart"] = Decimal(15) if sub < 99 and not member else Decimal(0)   # D3, D4
    fees["express"] = Decimal(25) if express else Decimal(0)                  # D5
    fees["rain"] = Decimal(10) if rain else Decimal(0)                        # D6
    hour = int(order_time.split(":")[0])
    fees["late_night"] = Decimal(20) if hour >= 23 or hour < 6 else Decimal(0)    # D7
    fees["platform"] = Decimal(5)                                              # D8
    fees["total"] = (sub + sum(fees.values())).quantize(Decimal("0.01"))      # D9
    return fees
