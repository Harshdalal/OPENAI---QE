"""A broken copy of fees.py for practice. Do not fix it: good tests should catch it."""
from decimal import Decimal


def calculate_fees(subtotal, member=False, express=False, rain=False, order_time="14:00"):
    sub = Decimal(str(subtotal))
    if sub < 0:
        raise ValueError("subtotal must not be negative")
    fees = {}
    free = sub >= 199 if member else sub > 499
    if free:
        fees["delivery"] = Decimal(0)
    elif sub < 199:
        fees["delivery"] = Decimal(30)
    else:
        fees["delivery"] = Decimal(20)
    fees["small_cart"] = Decimal(15) if sub < 99 and not member else Decimal(0)
    fees["express"] = Decimal(25) if express else Decimal(0)
    fees["rain"] = Decimal(10) if rain and not member else Decimal(0)
    hour = int(order_time.split(":")[0])
    fees["late_night"] = Decimal(20) if hour >= 23 or hour < 5 else Decimal(0)
    fees["platform"] = Decimal(5)
    fees["total"] = (sub + sum(fees.values())).quantize(Decimal("0.01"))
    return fees
