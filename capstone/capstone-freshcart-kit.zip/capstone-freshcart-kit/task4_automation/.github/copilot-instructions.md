# Instructions for GitHub Copilot in this folder

- Tests use pytest. Put them in tests/, in files named test_*.py.
- Use pytest.mark.parametrize for boundary tables, with an id for every case.
- Take expected values from docs/fee_rules.md, never by calling or copying the code under
  test. If the rules do not say, write a TODO question instead of guessing.
- Compare money with Decimal("..."), never with floats.
- Check single fee lines (delivery, small_cart, express, rain, late_night, platform) as well
  as the total, so a failure names the rule.
- One behaviour per test. Test names say the rule, for example test_d7_late_night_until_0559.
- No network calls, no sleeps, no real personal data.
