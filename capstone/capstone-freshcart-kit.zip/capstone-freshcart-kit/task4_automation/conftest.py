"""Lets you run the same tests against the broken implementation:

    USE_BUGGY=1 python -m pytest tests          (macOS or Linux)
    set USE_BUGGY=1 && python -m pytest tests   (Windows cmd)
    $env:USE_BUGGY=1; python -m pytest tests    (PowerShell)
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

if os.getenv("USE_BUGGY") == "1":
    import freshcart.fees_buggy as buggy

    sys.modules["freshcart.fees"] = buggy
    print("\n*** Running against freshcart/fees_buggy.py ***")
