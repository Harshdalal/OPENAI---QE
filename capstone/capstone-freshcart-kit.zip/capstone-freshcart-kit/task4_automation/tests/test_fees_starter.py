"""Starter file. Write your tests here with GitHub Copilot (see ../copilot_prompts.md).
Every expected value must come from docs/fee_rules.md, never from the code."""
from decimal import Decimal

from freshcart.fees import calculate_fees


def test_d9_agreed_example_1():
    assert calculate_fees(150)["total"] == Decimal("185.00")
