# Task 4: fee tests with GitHub Copilot

Open this folder (task4_automation) in VS Code with GitHub Copilot signed in with your
company account. Copilot reads .github/copilot-instructions.md automatically.
No Copilot? Write the tests by hand from the rules; the check at the end is the same.

## Prompt 1 (Copilot Chat, with docs/fee_rules.md and freshcart/fees.py attached)

Write pytest tests for calculate_fees in tests/test_fee_rules.py. Take every expected value
from docs/fee_rules.md, not from the code. Cover each rule D2 to D9 and a value just below,
at and just above every boundary: 99, 199 and 499 for shoppers and members, 23:00 and 06:00
for the late-night fee. Include all eight agreed examples. Use parametrize with ids.

## Prompt 2 (follow-up)

Which rules or boundaries in docs/fee_rules.md do these tests not cover? Add them, or a
TODO question if the rules do not say.

## Run

    python -m pytest tests -q                      must pass against freshcart/fees.py
    USE_BUGGY=1 python -m pytest tests -q          must fail: fees_buggy.py has three bugs

Windows cmd:   set USE_BUGGY=1 && python -m pytest tests -q
PowerShell:    $env:USE_BUGGY=1; python -m pytest tests -q

Done when: your tests pass on fees.py, and on fees_buggy.py at least one test fails for
each of the three bugs. Name the three bugs in your submission.
