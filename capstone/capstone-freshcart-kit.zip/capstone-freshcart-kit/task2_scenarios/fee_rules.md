# FreshCart fee rules: the source of truth (agreed 7 November 2026)

FreshCart is a fictional quick-commerce grocery app in Hyderabad. These rules replace the
draft REQ-FC-50. An AI answer, a test or a test row is correct only if it matches them.

## Rules

- D1. The subtotal is the item total. Every threshold below uses the subtotal only.
- D2. Delivery fee: INR 30 when the subtotal is below INR 199; INR 20 from INR 199 to INR 498.99; free from INR 499.
- D3. Small cart fee: INR 15 when the subtotal is below INR 99.
- D4. FreshPass members: delivery is free from INR 199 (INR 30 below INR 199), and no small cart fee.
- D5. Express delivery: INR 25, for everyone, even when delivery is free.
- D6. Rain surcharge: INR 10 when rain mode is on. It applies to FreshPass members too.
- D7. Late-night fee: INR 20 for orders placed from 23:00 to 05:59.
- D8. Platform fee: INR 5 on every order.
- D9. Total = subtotal + every fee, in rupees with two decimals. Every fee is its own line.

## Agreed examples

| ID | Subtotal | Member | Express | Rain | Time | Fees | Total (INR) |
|----|----------|--------|---------|------|------|------|-------------|
| 1 | 150.00 | No | No | No | 14:00 | delivery 30, platform 5 | 185.00 |
| 2 | 80.00 | No | No | No | 14:00 | delivery 30, small cart 15, platform 5 | 130.00 |
| 3 | 498.99 | No | No | No | 14:00 | delivery 20, platform 5 | 523.99 |
| 4 | 499.00 | No | No | No | 14:00 | platform 5 | 504.00 |
| 5 | 199.00 | Yes | No | No | 14:00 | platform 5 | 204.00 |
| 6 | 80.00 | Yes | No | No | 14:00 | delivery 30, platform 5 | 115.00 |
| 7 | 350.00 | No | Yes | Yes | 23:30 | delivery 20, express 25, rain 10, late night 20, platform 5 | 430.00 |
| 8 | 600.00 | Yes | Yes | Yes | 05:59 | express 25, rain 10, late night 20, platform 5 | 660.00 |

## Not in these rules

Coupons, delivery partner tips, GST, refunds and cancellation fees are not defined here.
