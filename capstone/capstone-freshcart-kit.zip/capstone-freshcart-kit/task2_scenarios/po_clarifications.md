# Product owner answers to the REQ-FC-50 review (Saturday 7 November)

Open this only after your team has finished Task 1.

1. "Above INR 499" was a mistake: delivery is free from INR 499.00 (at 499 it is free).
2. AC1 and AC2 together: INR 30 below INR 199; INR 20 from INR 199 up to INR 498.99; free from INR 499.
3. Small cart fee: INR 15 when the subtotal is below INR 99.
4. Express costs INR 25, for every shopper, even when delivery is free.
5. FreshPass members get free delivery from INR 199 (not on every order), and never pay the small cart fee.
6. Night means orders placed from 23:00 up to 05:59. At 06:00 there is no late-night fee.
7. We changed our mind on AC7: the rain surcharge (INR 10) applies to members too. It is not waived.
8. There is also a platform fee of INR 5 on every order; it was missing from the draft.
9. Thresholds use the item subtotal. Fees never count toward the thresholds.
10. AC8 "shown clearly" means every fee is a separate line on the checkout screen and the invoice.

The agreed rules are in fee_rules.md. They are the source of truth from now on.
