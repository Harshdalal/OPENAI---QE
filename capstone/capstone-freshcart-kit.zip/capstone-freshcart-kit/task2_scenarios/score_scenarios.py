"""Score saved AI scenarios against the FreshCart fee rules answer key. No AI and no Azure needed.

    python score_scenarios.py scenarios_run1.md
    python score_scenarios.py my_answer.md --format gherkin

Formats: table, checklist, gherkin, json. A rough pattern match: your team reads the
scenarios as well, and the rubric in the problem statement has the final say.
"""
import argparse
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent


def fmt_score(answer, fmt):
    if fmt == "json":
        try:
            raw = re.sub(r"^```(json)?|```$", "", answer.strip(), flags=re.M).strip()
            data = json.loads(raw)
            return (2 if isinstance(data, dict) and data.get("scenarios") else 1), "valid JSON"
        except ValueError as e:
            return 0, f"not valid JSON ({e})"
    if fmt == "gherkin":
        n = len(re.findall(r"^\s*Scenario( Outline)?:", answer, re.M))
        steps = all(re.search(rf"^\s*{k}\b", answer, re.M) for k in ("Given", "When", "Then"))
        return (2 if n >= 5 and steps else 1 if n else 0), f"{n} scenarios, Given/When/Then {'present' if steps else 'missing'}"
    if fmt == "checklist":
        n = len(re.findall(r"^\s*[-*]?\s*\[ \]", answer, re.M))
        return (2 if n >= 5 else 1 if n else 0), f"{n} checklist items"
    lines = answer.splitlines()
    rows = [l for l in lines if l.strip().startswith("|")]
    headers = {l.strip() for l in rows if re.match(r"^\|\s*(ID|Case)\b", l.strip())}
    prose = [l for l in lines if l.strip() and not l.strip().startswith("|") and not l.lower().startswith("questions")
             and not re.match(r"^\s*([-*]|\d+[.)])\s", l)]
    if len(rows) >= 5 and len(headers) <= 1 and len(prose) <= 1:
        return 2, f"{len(rows)} table rows, one consistent table"
    return (1 if rows else 0), f"{len(rows)} table rows, {len(headers)} different headers, {len(prose)} lines of prose"


def vague(answer):
    words = r"works correctly|as expected|properly|appropriate|gracefully|should (not )?work|\bfine\b|handled"
    return [l.strip()[:70] for l in answer.splitlines() if re.search(words, l, re.I)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("answer")
    ap.add_argument("--format", default="table", choices=["table", "checklist", "gherkin", "json"])
    args = ap.parse_args()
    keys = json.loads((HERE / "answer_key.json").read_text(encoding="utf-8"))
    key = keys["FEES"]
    answer = Path(args.answer).read_text(encoding="utf-8")
    m = re.search(r"questions for the product owner", answer, re.I)
    body, questions = (answer[:m.start()], answer[m.end():]) if m else (answer, "")

    acs = [a for a in key["acs"] if re.search(rf"\b{a}\b", answer)]
    ac_pts = round(6 * len(acs) / len(key["acs"]))
    found = [b["name"] for b in key["boundaries"] if re.search(b["pattern"], body, re.I)]
    q_items = [l for l in questions.splitlines() if re.match(r"\s*[-*\d]", l) and len(l.strip()) > 8]
    q_pts = 2 if q_items else 0
    f_pts, f_note = fmt_score(answer, args.format)
    inv = [i["name"] for i in keys["invented"] if re.search(i["pattern"], body, re.I)]
    total = max(0, ac_pts + len(found) + q_pts + f_pts - min(4, len(inv)))

    print(f"{Path(args.answer).name} against the FreshCart fee rules ({args.format})\n")
    print(f"  Rule coverage   {ac_pts}/6   ({len(acs)} of {len(key['acs'])} rules)")
    print(f"  Boundaries      {len(found)}/10")
    print(f"  Questions       {q_pts}/2")
    print(f"  Format          {f_pts}/2   ({f_note})")
    print(f"  Invention       -{min(4, len(inv))}     {', '.join(inv) if inv else 'none flagged'}")
    print(f"  TOTAL           {total}/20\n")
    missing = [b["name"] for b in key["boundaries"] if b["name"] not in found]
    if missing:
        print("Boundaries missing: " + "; ".join(missing))
    v = vague(body)
    if v:
        print(f"Vague expected results ({len(v)}): e.g. {v[0]!r}")
    print("\nRough pattern match only. Read the answer and check it against fee_rules.md.")


if __name__ == "__main__":
    main()
