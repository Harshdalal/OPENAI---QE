"""Task 2: send a prompt template plus the fee rules to your deployment and save the answer.

    python generate_scenarios.py --mock --out scenarios_mock.md        offline practice answer
    python generate_scenarios.py --out scenarios_run1.md               real model (tools/.env)
    python generate_scenarios.py --template my_template_v1.1.txt --out run2.md

The template has a ### SYSTEM part and a ### USER part; {rules} is replaced by fee_rules.md.
Score the saved answer with score_scenarios.py, then read it yourself.
"""
import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "tools"))
from aiclient import get_client, model  # noqa: E402

MOCK = """| ID | Title | Type | Rule | Test data | Expected result |
|----|-------|------|------|-----------|-----------------|
| FC-01 | Small cart fee just below 99 | Boundary | D3 | Subtotal 98.99, shopper | Small cart fee line shows INR 15. |
| FC-02 | No small cart fee at 99 | Boundary | D3 | Subtotal 99.00, shopper | No small cart fee line is shown. |
| FC-03 | Delivery INR 30 just below 199 | Boundary | D2 | Subtotal 198.99 | Delivery fee line shows INR 30. |
| FC-04 | Delivery INR 20 at 199 | Boundary | D2 | Subtotal 199.00 | Delivery fee line shows INR 20. |
| FC-05 | Delivery INR 20 just below 499 | Boundary | D2 | Subtotal 498.99 | Delivery fee line shows INR 20. |
| FC-06 | Free delivery at 499 | Boundary | D2 | Subtotal 499.00 | Delivery fee line shows INR 0. |
| FC-07 | Member free delivery from 199 | Boundary | D4 | Member, subtotal 199.00 | Delivery fee line shows INR 0. |
| FC-08 | Member pays INR 30 below 199 | Boundary | D4 | Member, subtotal 198.99 | Delivery fee line shows INR 30. |
| FC-09 | Express on a free delivery order | Positive | D5 | Subtotal 600.00, express | Express line shows INR 25 and delivery shows INR 0. |
| FC-10 | Rain surcharge | Positive | D6 | Subtotal 300.00, rain mode on | Rain line shows INR 10. |
| FC-11 | No late-night fee at 22:59 | Boundary | D7 | Subtotal 300.00, 22:59 | No late-night fee line is shown. |
| FC-12 | Late-night fee at 23:00 | Boundary | D7 | Subtotal 300.00, 23:00 | Late-night line shows INR 20. |
| FC-13 | Platform fee on every order | Positive | D8 | Subtotal 150.00 | Platform fee line shows INR 5. |
| FC-14 | Agreed example 7 total | Positive | D9 | 350.00, express, rain, 23:30 | Total shows INR 430.00. |
| FC-15 | Negative subtotal rejected | Negative | D1 | Subtotal -10.00 | Checkout shows error code FC-102. |

Questions for the product owner
1. What happens to the fees if items are removed after a fee was shown?
2. Is the late-night fee based on the time the order is placed or the time it is delivered?
3. Can a member also pay the small cart fee if their membership has expired during checkout?"""


def split(template):
    sys_part, _, user_part = template.partition("### USER")
    return sys_part.replace("### SYSTEM", "").strip(), user_part.strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", default=str(HERE / "template_v1.0_freshcart.txt"))
    ap.add_argument("--rules", default=str(HERE / "fee_rules.md"))
    ap.add_argument("--out", default="scenarios_run1.md")
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    system, user = split(Path(args.template).read_text(encoding="utf-8"))
    user = user.replace("{rules}", Path(args.rules).read_text(encoding="utf-8"))
    client = get_client(args.mock)
    if client is None:
        answer = MOCK
    else:
        answer = client.responses.create(model=model(), instructions=system, input=user).output_text
    Path(args.out).write_text(answer, encoding="utf-8")
    print(answer[:600] + ("\n..." if len(answer) > 600 else ""))
    print(f"\nSaved {args.out}. Next: python score_scenarios.py {args.out}")


if __name__ == "__main__":
    main()
