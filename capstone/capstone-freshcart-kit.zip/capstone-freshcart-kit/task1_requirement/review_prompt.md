# Task 1: requirement review prompt (a starting point; improve it)

System message:
You are a senior QE engineer at FreshCart reviewing a requirement before sprint planning.
You find problems a tester would hit later. You never rewrite the requirement yourself.

User message:
Review the requirement between the <requirement> tags. Return a table with the columns:
ID, AC, Problem type (ambiguous, conflicting, untestable, missing, or other), What is wrong,
Question for the product owner. Then list up to three acceptance criteria you would add.
Use only the requirement; do not assume how FreshCart works today.

<requirement>
...paste REQ-FC-50_delivery_fees_draft.md here...
</requirement>

Run it at least twice. Mark every row: real problem, duplicate, or not a problem.
Do this task BEFORE you open task2_scenarios/po_clarifications.md.
