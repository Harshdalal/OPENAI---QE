# REQ-FC-50: Delivery and order fees at checkout (DRAFT)

Product: FreshCart app (Android, iOS and web)
Owner: Checkout squad
Status: Draft, for review before sprint planning
Release: fees build 3.4.0, planned for Monday 9 November 2026

## Story

As a FreshCart shopper, I want to see every fee before I pay, so that I know exactly what my
order will cost.

## Acceptance criteria

- AC1. Delivery is free for orders above INR 499.
- AC2. Orders below INR 199 pay INR 30 for delivery; other orders pay INR 20.
- AC3. A small cart fee applies to small orders.
- AC4. Express delivery (within 15 minutes) costs extra.
- AC5. FreshPass members get free delivery.
- AC6. A late-night fee of INR 20 applies to orders placed at night.
- AC7. A rain surcharge applies in bad weather and is waived for FreshPass members.
- AC8. Fees should be shown clearly at checkout.

## Out of scope

Coupons, tips for delivery partners and GST calculation.
