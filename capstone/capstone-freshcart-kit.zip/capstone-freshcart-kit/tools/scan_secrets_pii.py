"""Scan AI outputs (or any folder) for secrets, personal data and risky code patterns.

    python tools/scan_secrets_pii.py                 scans task6_responsible_ai/ai_bundle/
    python tools/scan_secrets_pii.py path/to/folder

A teaching scanner built from regular expressions. In real projects use a maintained tool
as well, such as GitHub secret scanning with push protection, gitleaks, or bandit for Python.
It finds patterns, not intent: read every hit and decide.
"""
import re
import sys
from pathlib import Path

RULES = [
    ("SECRET", "OpenAI-style API key", r"\bsk-[A-Za-z0-9_-]{20,}"),
    ("SECRET", "AWS access key ID", r"\bAKIA[0-9A-Z]{16}\b"),
    ("SECRET", "Password in code or config", r"(?i)\b(password|passwd|pwd)\b\s*[=:]\s*['\"]?[^\s'\";]{4,}"),
    ("SECRET", "Connection string with password", r"(?i)Password=[^;\s]+"),
    ("SECRET", "Live API key", r"\bsk-live-[A-Za-z0-9_-]{8,}"),
    ("SECRET", "Token printed or logged", r"(?i)print\(.*token"),
    ("PII", "Email outside example.com", r"\b[\w.+-]+@(?!example\.(?:com|org|net)\b)[\w-]+(\.[\w-]+)+\b"),
    ("PII", "Indian mobile number", r"\+91[\s-]?[6-9]\d{4}[\s-]?\d{5}\b"),
    ("PII", "PAN number format", r"\b[A-Z]{5}\d{4}[A-Z]\b"),
    ("PII", "Card number (not a known test card)", r"\b(?!4111[\s-]?1111[\s-]?1111[\s-]?1111)(?!5500[\s-]?0000[\s-]?0000[\s-]?0004)\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b"),
    ("PII", "Note says data came from production", r"(?i)(production export|from prod|real customer|real-looking)"),
    ("CODE", "TLS verification turned off", r"verify\s*=\s*False"),
    ("CODE", "SQL built with an f-string", r"(?i)f[\"'][^\"']*\b(SELECT|INSERT|UPDATE|DELETE)\b"),
    ("CODE", "Fixed sleep in a test", r"time\.sleep\(\s*\d+"),
    ("CODE", "Swallowed assertion", r"except AssertionError:\s*\n\s*pass"),
    ("CODE", "Production URL in a test", r"https://www\.freshcart\.example"),
    ("PII", "UPI ID not at @testbank", r"\b[\w.-]+@(?!testbank\b)[a-z]+\b(?![.\w])"),
    ("PII", "Home address", r"(?i)\b\d+ [A-Z][a-z]+ (?:[A-Z][a-z]+ )?(?:Road|Street|Lane|Main)\b"),
]


def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "task6_responsible_ai" / "ai_bundle"
    hits = 0
    for path in sorted(p for p in root.rglob("*") if p.is_file() and p.suffix in {".py", ".md", ".csv", ".txt", ".json", ".env", ".yaml", ".yml"}):
        text = path.read_text(encoding="utf-8", errors="ignore")
        found = []
        for kind, name, pattern in RULES:
            for m in re.finditer(pattern, text):
                line = text.count("\n", 0, m.start()) + 1
                found.append((line, kind, name, m.group(0).strip()[:50]))
        if found:
            print(f"\n{path.relative_to(root.parent)}")
            for line, kind, name, snippet in sorted(set(found)):
                print(f"  line {line:<3} {kind:<7} {name}: {snippet}")
            hits += len(set(found))
    print(f"\n{hits} findings. Read each one: some are true problems, some are allowed test values.")
    print("The scanner does not catch wrong logic, invented facts or injected instructions. People and tests do.")


if __name__ == "__main__":
    main()
