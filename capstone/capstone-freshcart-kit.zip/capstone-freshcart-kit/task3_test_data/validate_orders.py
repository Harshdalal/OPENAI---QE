"""Check AI-generated order test data against the FreshCart fee rules, in code.

    python validate_orders.py                         checks ai_generated_orders.csv
    python validate_orders.py my_orders.csv

The model wrote expected_total; this script recomputes every total from fee_rules.md (D1 to D9),
written here by hand, and flags each row where they differ, plus data that looks real.
"""
import csv
import re
import sys
from decimal import Decimal
from pathlib import Path

SAFE_EMAIL = re.compile(r"^[\w.+-]+@example\.(com|org|net)$")


def rules_total(subtotal, member, express, rain, order_time):
    sub = Decimal(subtotal)
    lines = {}
    if sub < 199:
        lines["delivery"] = 30                                        # D2, D4
    elif sub >= (199 if member else 499):
        lines["delivery"] = 0
    else:
        lines["delivery"] = 20
    lines["small_cart"] = 15 if sub < 99 and not member else 0        # D3, D4
    lines["express"] = 25 if express else 0                           # D5
    lines["rain"] = 10 if rain else 0                                 # D6
    hour = int(order_time.split(":")[0])
    lines["late_night"] = 20 if hour >= 23 or hour < 6 else 0         # D7
    lines["platform"] = 5                                             # D8
    return (sub + sum(lines.values())).quantize(Decimal("0.01")), lines


def check_row(r):
    yes = lambda k: r[k].strip().lower() in ("yes", "y", "true", "1")
    total, lines = rules_total(r["subtotal_inr"], yes("member"), yes("express"), yes("rain"), r["order_time"])
    problems = []
    if Decimal(r["expected_total"]) != total:
        fees = ", ".join(f"{k} {v}" for k, v in lines.items() if v)
        problems.append(f"expected_total is {r['expected_total']}, rules give {total} ({fees})")
    if not SAFE_EMAIL.match(r["email"]):
        problems.append(f"email {r['email']} is not at example.com: it may be real personal data")
    if not r["order_id"].startswith("TEST-"):
        problems.append("order_id does not start with TEST-")
    return problems


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("ai_generated_orders.csv")
    with path.open(encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    bad = 0
    print(f"Checking {len(rows)} rows in {path.name}\n")
    for r in rows:
        problems = check_row(r)
        if problems:
            bad += 1
            print(f"{r['order_id']}  ({r['purpose']})")
            for p in problems:
                print(f"   - {p}")
    print(f"\n{bad} of {len(rows)} rows have problems." if bad else "\nEvery row matches the rules.")
    print("Coverage is your job: the script checks values, not whether a boundary is missing.")


if __name__ == "__main__":
    main()
