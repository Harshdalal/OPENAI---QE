# Task 3: the prompt that produced ai_generated_orders.csv

System message:
You are a QE engineer at FreshCart. You write test data only from the rules you are given.

User message:
Using the fee rules between the <rules> tags, write 16 rows of CSV test data for the
checkout fee calculator with the columns:
order_id,email,subtotal_inr,member,express,rain,order_time,expected_total,purpose
Cover every rule D2 to D8 and the boundaries of each. Use order IDs starting TEST- and
emails at example.com only. Only output the CSV.

<rules>
...fee_rules.md...
</rules>
