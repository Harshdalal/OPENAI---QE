"""Capstone Task 5: failed test run analysis and a release summary.

    python summarize_run.py                     digest only: no AI, no Azure
    python summarize_run.py --ask --mock        digest, then a practice AI analysis
    python summarize_run.py --ask               digest, then a real AI analysis

Step 1 is plain code: parse the JUnit XML, count results and group failures by signature.
Step 2 sends only that short digest and the log excerpt to the model, not the whole report.
"""
import argparse
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "tools"))
from aiclient import ask, get_client  # noqa: E402

INSTRUCTIONS = (
    "You are a QE lead at FreshCart triaging a nightly test run. Use only the digest and the log excerpt. "
    "For each failure group, give: likely cause, category (product bug, test bug, environment, or flaky), "
    "evidence quoted from the input, and the next action with an owner role. Then write a release "
    "summary of at most 6 lines for a product manager: counts, risks, and a go or no-go recommendation "
    "with its condition. If the evidence is not enough, say so."
)

MOCK = """| Group | Tests | Likely cause | Category | Evidence | Next action |
|---|---|---|---|---|---|
| 1 | 2 fee tests at 499.00 | Free delivery starts above 499 instead of from 499 | Product bug | build 3.4.0 "free delivery for orders above 499, per REQ-FC-50 AC1"; delivery 20.00 at 499.00 | Raise a bug for the checkout squad (dev) |
| 2 | 2 UPI payment tests | Payment sandbox maintenance | Environment | "maintenance 01:40 to 02:20" (ENV-901); timeouts at 01:44 and 01:52 | Rerun after 02:20 (QE) |
| 3 | test_slot_picker_next_day | List re-rendered during the click | Flaky | "passed on retry 1 of 2" | Add an explicit wait; track flakiness (QE) |
| 4 | test_invoice_fee_lines | Test expects "INR 5"; invoices now show "INR 5.00" | Test bug | CR-311 "money on invoices shown with two decimals" | Update the test (QE) |

Release summary
46 tests: 39 passed, 6 failed, 1 skipped (rain mode flag off).
One product bug: orders of exactly INR 499 are charged INR 20 delivery.
Two payment failures came from planned sandbox maintenance.
One flaky slot test and one test bug on invoices.
Recommendation: no-go for build 3.4.0 until the INR 499 boundary is fixed."""


def digest(xml_path):
    root = ET.parse(xml_path).getroot()
    counts = defaultdict(int)
    groups = defaultdict(list)
    for case in root.iter("testcase"):
        counts["total"] += 1
        fail = case.find("failure")
        if fail is None:
            fail = case.find("error")
        if case.find("skipped") is not None:
            counts["skipped"] += 1
        elif fail is not None:
            counts["failed"] += 1
            sig = f"{fail.get('type')}: " + re.sub(r"\d+", "N", fail.get("message", ""))[:90]
            detail = (fail.text or "").strip().splitlines()[-1]
            groups[sig].append((case.get("classname"), case.get("name"), detail))
        else:
            counts["passed"] += 1
    lines = [f"Run {root.get('name')} at {root.get('timestamp')}",
             f"Total {counts['total']}: passed {counts['passed']}, failed {counts['failed']}, skipped {counts['skipped']}",
             f"Failure groups: {len(groups)}"]
    for i, (sig, cases) in enumerate(sorted(groups.items(), key=lambda g: -len(g[1])), 1):
        lines.append(f"\nGroup {i} ({len(cases)} test{'' if len(cases) == 1 else 's'}): {sig}")
        for cls, name, detail in cases:
            lines.append(f"  - {cls}.{name}: {detail}")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xml", default=str(HERE / "junit_nightly_2026-11-08.xml"))
    ap.add_argument("--log", default=str(HERE / "app_log_excerpt.txt"))
    ap.add_argument("--ask", action="store_true", help="send the digest to the model")
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()

    text = digest(args.xml)
    print(text)
    full = Path(args.xml).stat().st_size
    print(f"\n(The digest is {len(text)} characters; the full report is {full}. Send the digest, not the report.)")
    if not args.ask:
        print("\nAdd --ask to have the model group causes and draft a release summary.")
        return
    log = Path(args.log).read_text(encoding="utf-8")
    client = get_client(args.mock)
    answer = ask(client, INSTRUCTIONS, f"<digest>\n{text}\n</digest>\n\n<log>\n{log}\n</log>", MOCK)
    print("\n" + "=" * 70 + "\n" + answer)
    print("\nCheck every cause against the evidence before it goes in a bug or a release note.")


if __name__ == "__main__":
    main()
