# Capstone kit: FreshCart checkout fees

FreshCart is a fictional quick-commerce grocery app in Hyderabad. Fees build 3.4.0 is due to
release on Monday 9 November 2026. Your team is the QE team. Use AI, safely, to decide
whether it can ship. The full brief is in Capstone_Problem_Statement_FreshCart.docx.

| Folder | Task | Modules | Runs offline? |
|--------|------|---------|---------------|
| task1_requirement | Review the draft REQ-FC-50 | 1, 3, 4 | Playground prompt |
| task2_scenarios | Prompt template, scenarios, score | 2, 3 | generate_scenarios.py --mock; score_scenarios.py |
| task3_test_data | Check AI-written order data in code | 4 | validate_orders.py |
| task4_automation | Fee tests with Copilot, proven on a buggy copy | 4, 5 | pytest |
| task5_nightly | Triage the nightly run; go or no-go | 4 | summarize_run.py, add --ask --mock |
| task6_responsible_ai | Review an AI bundle; prompt injection | 5 | scan_secrets_pii.py, bandit, triage_demo.py --mock |
| task7_canvas | Plan FreshCart's next AI use case | 4 | Word form |

Order: do Task 1 before you open task2_scenarios/po_clarifications.md. After that,
fee_rules.md is the source of truth for every task.

Setup (Python 3.10 or later), from this folder:

    python -m pip install -r tools/requirements.txt
    copy tools\.env.example tools\.env          macOS or Linux: cp tools/.env.example tools/.env

Fill tools/.env with your Module 2 values to use a real model, or add --mock to every
script. Never commit .env. Run each script from its own folder.

Submit: team_submission_template.md, filled in, plus your test file and scenarios file.
All names, IDs, keys and data in this kit are fictional.
