# Module 1 exercise kit: CityHop

Self-paced practice for Module 1 on a new case study. Do the main Module 1 lab (ShopEasy) first.

- case_study.md        the scenario
- fare_rules.md        fare rules F1 to F8 and agreed examples (source of truth)
- data/                reviews, trip log, driver chat, receipt (PNG and text), call transcript
- prompts.md           every prompt used in Exercises 4 to 7
- worksheet.md         record your answers
- scripts/             optional: practice_settings.py (add --mock to run offline)

Instructions: Module1_Exercise_Manual_CityHop.docx
Answers: Module1_Exercise_Solutions_CityHop.docx (try first)

Optional script (Python 3.10 or later):

    cd scripts
    python -m pip install -r requirements.txt
    python practice_settings.py --mock
    copy .env.example .env          macOS or Linux: cp .env.example .env
    python practice_settings.py --runs 3

Never commit .env. CityHop and all names, IDs and amounts in this kit are fictional.
