# CityHop exercise prompts (copy and paste)

Start a new chat before every run. Keep temperature at 0 unless an exercise says otherwise.

## System message R (Exercises 6 and 7)

You are a QA assistant for the CityHop team. Use these fare rules:

<paste the whole of fare_rules.md here>

## Exercise 4: text analysis (no system message, temperature 0)

For the app reviews below, give me:
1. The five main keywords.
2. Every entity: ride IDs, ticket IDs, places, amounts, error codes, phone models, dates.
3. A table with the sentiment of each review: positive, negative, neutral or mixed, and one
   word on why.
4. A three-line summary for the product manager.

<reviews>
<paste data/rider_reviews.txt here>
</reviews>

## Exercise 5a: extraction from the receipt (temperature 0)

Attach data/ride_receipt.png (or paste data/ride_receipt.txt if your model does not accept
images) and send:

Extract these fields from the receipt as JSON: ride_id, date, start_time, pickup, drop,
distance_km, ride_time_min, base_fare, distance_charge, time_charge, night_charge,
surge_charge, total, payment_method. Use numbers for amounts. Use null for anything missing.
Do not calculate anything; copy what is printed.

## Exercise 5c: extraction from the call transcript (temperature 0)

Extract these fields from the call transcript as JSON: call_id, ride_id (format CH-00000),
pickup, drop, quoted_fare_inr, charged_fare_inr, issues (list), requested_action,
rider_sentiment, contact_email. Use null for anything not said.

<transcript>
<paste data/complaint_call_transcript.txt here>
</transcript>

## Exercise 6: Prompt F, one right answer

What is the fare for an 18 km ride of 41 minutes that starts at 14:00 with a surge of 1.3?
Reply with the amount in rupees only.

## Exercise 6: Prompt G, many good answers

Write three short push notifications (under 12 words each) inviting riders to try CityHop
for their airport trip.

## Exercise 7: Prompt H, the trap

What is CityHop's cancellation fee, and how many days does a refund take?

## Exercise 7: the grounding line (add to the end of System message R)

Answer only from the fare rules. If the rules do not say, reply exactly: Not in the fare rules.

## Exercise 7: Prompt I, boundaries

Answer each with yes or no and the rule number: Is the night charge applied to a ride that
starts at (a) 22:59, (b) 23:00, (c) 04:59, (d) 05:00?
