# Case study: CityHop rides

CityHop is a fictional ride-hailing app in Bengaluru. Riders book cabs in the app, pay by
UPI or card, and rate their ride. The CityHop QE team (you) tests the rider app, the fare
engine and the support tools.

This month the team wants to know where AI could help, and where it could hurt. Your job
in these exercises is to try the Module 1 ideas on CityHop material:

- fare_rules.md                  the fare rules and agreed examples (source of truth)
- data/rider_reviews.txt         15 app store reviews, some in Hinglish
- data/trip_log_sample.csv       20 lines from the trip log
- data/driver_chat_hinglish.txt  a driver support chat in English, Hinglish and Hindi
- data/ride_receipt.png          a ride receipt image (and ride_receipt.txt, the same text)
- data/complaint_call_transcript.txt  speech-to-text output of a rider's complaint call
- prompts.md                     every prompt used in the exercises
- worksheet.md                   record your answers here

All names, IDs, phone numbers and amounts are fictional.
