"""Optional: run Exercise 6 Prompt F and Exercise 7 Prompt H automatically.

    python practice_settings.py --mock        practice run, no Azure needed
    python practice_settings.py               real run (reads .env; same values as the Module 1 lab)
    python practice_settings.py --temps 0 0.7 1.5 --runs 5

Prints how often Prompt F gave the right fare (382) at each temperature, and whether Prompt H
invented a cancellation fee with and without the grounding line.
"""
import argparse
import os
import random
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
KIT = HERE.parent
F = "What is the fare for an 18 km ride of 41 minutes that starts at 14:00 with a surge of 1.3? Reply with the amount in rupees only."
H = "What is CityHop's cancellation fee, and how many days does a refund take?"
GROUND = "Answer only from the fare rules. If the rules do not say, reply exactly: Not in the fare rules."
EXPECTED = 382


def is_right(answer):
    """382 counts (also 382.00 or INR 382); 381.55 on its own does not (rule F8 rounds)."""
    nums = [float(x.replace(",", "").rstrip(".")) for x in re.findall(r"\d[\d,]*\.?\d*", answer)]
    return EXPECTED in nums


def load_env():
    p = HERE / ".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def system(grounded):
    text = "You are a QA assistant for the CityHop team. Use these fare rules:\n\n" + (KIT / "fare_rules.md").read_text(encoding="utf-8")
    return text + ("\n\n" + GROUND if grounded else "")


class Mock:
    """Invented answers that imitate typical behaviour. Not a model."""
    rng = random.Random(3)

    def ask(self, sys_msg, prompt, t):
        if prompt == F:
            return self.rng.choice(["382", "381.55", "INR 382", "390"]) if t >= 1.4 else ("382" if t < 0.5 or self.rng.random() < 0.8 else "381.55")
        if GROUND in sys_msg:
            return "Not in the fare rules"
        return self.rng.choice(["The cancellation fee is INR 50 and refunds take 5 to 7 working days.",
                                "CityHop charges INR 30 to cancel after 5 minutes; refunds take 3 days."])


class Real:
    def __init__(self):
        from openai import OpenAI
        self.client = OpenAI(base_url=os.environ["OPENAI_BASE_URL"], api_key=os.environ["OPENAI_API_KEY"])
        self.model = os.environ["MODEL_DEPLOYMENT"]

    def ask(self, sys_msg, prompt, t):
        try:
            return self.client.responses.create(model=self.model, instructions=sys_msg, input=prompt,
                                                temperature=t, max_output_tokens=200).output_text.strip()
        except Exception as e:  # e.g. a reasoning model that rejects temperature
            return f"ERROR {type(e).__name__}: {str(e)[:80]}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--temps", nargs="+", type=float, default=[0.0, 1.0, 1.5])
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    load_env()
    if args.mock:
        print("MOCK MODE: answers are invented by the script, not by a model.\n")
        m = Mock()
    else:
        missing = [k for k in ("OPENAI_BASE_URL", "OPENAI_API_KEY", "MODEL_DEPLOYMENT") if not os.getenv(k)]
        if missing:
            sys.exit(f"Missing in scripts/.env: {', '.join(missing)}. Copy .env.example to .env, or add --mock.")
        m = Real()

    print(f"Prompt F (right answer {EXPECTED}):")
    for t in args.temps:
        answers = [m.ask(system(False), F, t) for _ in range(args.runs)]
        right = sum(1 for a in answers if is_right(a))
        print(f"  temp {t:<4} correct {right}/{len(answers)}   distinct {len(set(answers))}   {answers}")
    print("\nPrompt H (the trap):")
    for grounded in (False, True):
        a = m.ask(system(grounded), H, 0.0)
        verdict = "said not in the rules" if "not in the fare rules" in a.lower() else "gave an answer (check: is it invented?)"
        print(f"  grounded={grounded!s:<5} {verdict}\n      {a[:110]}")
    print("\nRemember: 381.55 is not a correct fare. Rule F8 rounds to whole rupees.")


if __name__ == "__main__":
    main()
