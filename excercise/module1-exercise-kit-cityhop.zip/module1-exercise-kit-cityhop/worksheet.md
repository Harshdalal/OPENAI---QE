# CityHop exercise worksheet (Module 1)

Name: ____________________   Tool and model used: ____________________

## Exercise 1: tokens and the context window

| File or line | Characters | Tokens | Characters per token |
|--------------|-----------|--------|----------------------|
| fare_rules.md | | | |
| data/rider_reviews.txt | | | |
| data/trip_log_sample.csv | | | |
| Chat line 1 (English) | | | |
| Chat line 3 (Hinglish with IDs) | | | |
| Chat line 5 (Hindi) | | | |

Trip log: tokens per row = ______

Budget: a model with a 128,000-token window; 1,000 tokens of instructions; 4,000 for the answer.
Rows that fit: ______   Does a full day of 5,000 trips fit? ______

## Exercise 2: what kind of AI is it?

| # | Feature | AI, ML, generative AI, LLM, or no AI | Workload |
|---|---------|--------------------------------------|----------|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |
| 6 | | | |
| 7 | | | |
| 8 | | | |
| 9 | | | |
| 10 | | | |

## Exercise 3: generative or agentic?

| Scenario | Generative or agentic | One guardrail |
|----------|-----------------------|---------------|
| A | | |
| B | | |
| C | | |
| D | | |

## Exercise 4: text analysis

Keywords the model found: ____________________   Entities it missed: ____________________

Reviews where your sentiment differs from the model's, and why: ____________________

## Exercise 5: extraction

5a. Fields wrong or missing: ____________________
5b. Correct total by the fare rules: INR ______   Receipt total: INR ______   Which line is wrong? ______
5c. Fields wrong or missing: ____________________

## Exercise 6: settings

| Temperature | Run | Prompt F answer | Correct (382)? | Prompt G: same / some / very different |
|-------------|-----|-----------------|----------------|----------------------------------------|
| 0 | 1 | | | |
| 0 | 2 | | | |
| 0 | 3 | | | |
| 1.0 | 1 | | | |
| 1.0 | 2 | | | |
| 1.0 | 3 | | | |
| 1.5 | 1 | | | |
| 1.5 | 2 | | | |
| 1.5 | 3 | | | |

Max output tokens 20: what happened to the answer? ____________________

## Exercise 7: hallucination and grounding

| Run | Grounded? | Temperature | Invented a fee or refund time? | What it said |
|-----|-----------|-------------|--------------------------------|--------------|
| H1 | no | 0 | | |
| H2 | no | 1.0 | | |
| H3 | yes | 0 | | |

Prompt I answers: (a) ____ (b) ____ (c) ____ (d) ____   All correct? ____

## Exercise 8: model and deployment

| Scenario | Model capability | Deployment type | Why |
|----------|------------------|-----------------|-----|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |

## Exercise 9: self-check

Score: ____ / 10
