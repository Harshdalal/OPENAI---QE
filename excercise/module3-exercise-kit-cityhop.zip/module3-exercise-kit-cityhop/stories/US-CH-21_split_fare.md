# US-CH-21: Split the fare with friends

Product: CityHop rider app (fictional)
Status: Ready for test

## Story

As a CityHop rider, I want to split the fare with friends riding with me, so that each of us
pays our own share.

## Acceptance criteria

- AC1. The booker can split a fare between 2 and 4 riders, including themselves.
- AC2. The fare is divided equally and each share is rounded down to whole rupees. Any
  remainder is added to the booker's share.
- AC3. A split is allowed only if every share is at least INR 25.
- AC4. Each friend gets an invite that expires 10 minutes after it is sent.
- AC5. A friend who declines, or whose invite expires, is removed; the booker pays that share.
- AC6. Split fare works only with UPI and card payments, not cash or wallet.
- AC7. Invites can be accepted only until the ride ends.

## Out of scope

Splitting by distance, splitting tips, and splitting with riders who do not have the app.
