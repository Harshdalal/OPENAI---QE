# US-CH-22: Rate your driver

Product: CityHop rider app (fictional)
Status: Ready for test

## Acceptance criteria

- AC1. After a completed ride, the rider can rate the driver from 1 to 5 stars.
- AC2. A rating of 1 or 2 stars requires a reason chosen from a list.
- AC3. An optional comment can be up to 200 characters.
- AC4. The rating can be changed within 24 hours of the ride ending, then it is locked.
- AC5. Cancelled rides cannot be rated.
