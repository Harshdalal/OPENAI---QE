| ID | Title | Type | AC | Expected result |
|----|-------|------|----|-----------------|
| TS-01 | Split between 2 riders | boundary | AC1 | Split is allowed. |
| TS-02 | Split between 5 riders | boundary | AC1 | Split is rejected. |

TS-03 Remainder: when INR 100 is split between 3 riders, the booker pays 34 and the friends pay 33 each, which matches AC2.

Test 4 (priority high) - expiry: send an invite and wait 10 minutes; it should expire. Also try 9 minutes.

- [ ] Cash and wallet are not offered for split fare
- [ ] Accepting after the ride ends is blocked

| Case | Steps | Result |
|------|-------|--------|
| 7 | Split INR 99 between 4 riders | Rejected, share would be 24 |
