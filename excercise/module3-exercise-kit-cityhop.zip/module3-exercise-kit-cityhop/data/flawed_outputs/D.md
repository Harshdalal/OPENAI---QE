| ID | Title | Type | AC | Expected result |
|----|-------|------|----|-----------------|
| TS-01 | 2 riders split | boundary | AC1 | Works correctly. |
| TS-02 | 5 riders split | boundary | AC1 | Should not work. |
| TS-03 | INR 100 between 3 riders | boundary | AC2 | Remainder handled properly. |
| TS-04 | INR 99 between 4 riders | boundary | AC3 | Appropriate message is shown. |
| TS-05 | Invite at 10 minutes | boundary | AC4 | Behaves as expected. |
| TS-06 | Friend declines | negative | AC5 | Split happens. |
| TS-07 | Cash payment | negative | AC6 | Handled gracefully. |
| TS-08 | Accept after ride ends | negative | AC7 | Fine. |
