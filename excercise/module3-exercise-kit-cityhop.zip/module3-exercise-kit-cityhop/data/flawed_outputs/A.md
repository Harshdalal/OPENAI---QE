| ID | Title | Type | AC | Expected result |
|----|-------|------|----|-----------------|
| TS-01 | Split fare with a friend | positive | AC1 | Both riders see their share. |
| TS-02 | Equal shares | positive | AC2 | The fare is divided equally. |
| TS-03 | Minimum share | positive | AC3 | Shares respect the minimum. |
| TS-04 | Invite expiry | negative | AC4 | The invite expires. |
| TS-05 | Friend declines | negative | AC5 | The booker pays the declined share. |
| TS-06 | Payment by UPI | positive | AC6 | Split works with UPI. |
| TS-07 | Accept during the ride | positive | AC7 | The friend can accept during the ride. |

Questions for the product owner:
- Can the booker cancel a split after friends accept?
