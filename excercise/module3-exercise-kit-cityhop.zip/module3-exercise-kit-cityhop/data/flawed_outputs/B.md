| ID | Title | Type | AC | Expected result |
|----|-------|------|----|-----------------|
| TS-01 | Split between 6 riders | positive | AC1 | Each of the 6 riders pays an equal share. |
| TS-02 | Split with 5 riders in an SUV | boundary | AC1 | Allowed for SUV bookings. |
| TS-03 | Invite expires after 15 minutes | boundary | AC4 | Invite shows "Expired" at 15:00. |
| TS-04 | Split request when a friend is offline | negative | AC5 | The split API returns HTTP 409 with error code SPL-02. |
| TS-05 | Cash split | negative | AC6 | The app shows "Cash split is coming soon". |
| TS-06 | Share below INR 25 | boundary | AC3 | INR 99 among 4 riders is rejected. |
