"""Optional: send a prompt file to your deployment and save the answer, ready for score_answer.py.

    python run_prompt.py ../prompts/template_v1.1_cityhop.txt --story ../stories/US-CH-21_split_fare.md --out answer.md
    python run_prompt.py my_prompt.txt --story ../stories/US-CH-22_rate_driver.md --runs 2

A prompt file has a "### SYSTEM" part and a "### USER" part; {story} is replaced by the story.
{company} and {platform} default to CityHop values. There is no mock mode: without Azure,
paste your prompt into any approved chat tool and save the answer by hand.
"""
import argparse
import re
from pathlib import Path

from aiclient import get_client, model

DEFAULTS = {"company": "CityHop", "platform": "the CityHop rider app"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("prompt")
    ap.add_argument("--story", required=True)
    ap.add_argument("--out", default="answer.md")
    ap.add_argument("--runs", type=int, default=1)
    args = ap.parse_args()
    text = Path(args.prompt).read_text(encoding="utf-8")
    system, user = text.split("### USER", 1) if "### USER" in text else ("", text)
    system = system.replace("### SYSTEM", "").strip()
    values = {**DEFAULTS, "story": Path(args.story).read_text(encoding="utf-8")}
    fill = lambda t: re.sub(r"\{(\w+)\}", lambda m: values.get(m.group(1), m.group(0)), t)
    client = get_client(False)
    for i in range(1, args.runs + 1):
        kw = {"instructions": fill(system)} if system and not system.startswith("(leave empty)") else {}
        answer = client.responses.create(model=model(), input=fill(user.strip()), **kw).output_text
        out = Path(args.out) if args.runs == 1 else Path(args.out).with_stem(f"{Path(args.out).stem}_run{i}")
        out.write_text(answer, encoding="utf-8")
        print(f"Saved {out}. Score it: python score_answer.py {out} --story <US-CH-21 or US-CH-22>")


if __name__ == "__main__":
    main()
