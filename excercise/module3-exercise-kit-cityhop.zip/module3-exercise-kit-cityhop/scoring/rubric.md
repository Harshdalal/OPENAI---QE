# Prompt scoring rubric (20 points)

Score each answer against the story, not against how good it sounds.
The boundary list for each story is in answer_keys.json (and in the solutions document).

| Area | Points | How to score |
|------|--------|--------------|
| AC coverage | 6 | 6 x (criteria with at least one scenario / all criteria), rounded. |
| Boundaries | 10 | 1 point for each boundary in the answer key that appears as a scenario or item. |
| Questions for the product owner | 2 | 2 if there is a list with at least one real gap; 1 if gaps are mentioned in passing; 0 if none. |
| Format | 2 | 2 if exactly the format asked for (table, checklist, Gherkin or valid JSON); 1 if close; 0 if not. |
| Invention | minus 1 each, up to minus 4 | Anything not in the story: endpoints, HTTP codes, error codes, new limits or messages. |

Asking about something in "Questions for the product owner" is not inventing it.
Run each prompt at least twice and record the lower score too.
scripts/score_answer.py gives a rough automatic score; a person has the final say.
