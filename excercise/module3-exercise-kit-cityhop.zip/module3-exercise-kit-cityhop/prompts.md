# CityHop Module 3 exercise prompts

Start a new chat for every run. Keep temperature at the deployment default.

## Exercise 1: five weak prompts to diagnose (do not run them first; diagnose on paper)

P1: Test cases for split fare.

P2: You are a tester. Write 50 test cases for US-CH-21 in a nice format.
    (followed by the story)

P3: Write scenarios for the story below. Don't make anything up. Don't be vague. Don't miss
    boundaries. (followed by the story)

P4: The story is split fare, AC1 2 to 4 riders AC2 divided equally... (story text typed into
    the instructions with no separation) ...also write it as JSON and as a table and also
    summarise the story for the product owner and suggest UI improvements.

P5: (a good five-part prompt that ends with) For anything the story does not say, use your
    judgement as an experienced tester and fill in sensible values.

## Exercise 4: few-shot example rows (from a different feature: save a home address)

| ID    | Title                                   | Type     | AC  | Test data             | Expected result |
|-------|-----------------------------------------|----------|-----|-----------------------|-----------------|
| TS-01 | Save a home address with a valid PIN    | positive | AC1 | PIN 560001            | Address appears under Saved places as Home. |
| TS-02 | PIN code of 5 digits is rejected        | boundary | AC2 | PIN 56000             | Save stays disabled and the PIN field shows the 6-digit rule. |

Add after them: "Copy the style of these rows, not their content."

## Exercise 5: step-by-step block (add before the format line of your Exercise 3 prompt)

Work in three visible steps.
Step 1. Make a table of every number, time, limit and list in the story, with values just
below, at and just above each one. Columns: Rule, AC, Below, At, Above.
Step 2. List what the story does not say that a tester would need.
Step 3. Write the scenarios, using every row from Step 1 at least once.

## Exercise 6: format lines (replace your format line with one of these)

Gherkin: Write one Feature with one Scenario per test, using Given, When and Then. Put the AC
number in each scenario title. No text outside the Gherkin.

Checklist: One line per item, starting with "[ ]", grouped under headings AC1 to AC7. Boundary
items first in each group.

JSON: Reply with one JSON object only, no other text, in this shape:
{"story_id": "US-CH-21", "scenarios": [{"id": "TS-01", "title": "...", "type": "positive |
negative | boundary", "ac": ["AC1"], "test_data": "...", "expected_result": "..."}],
"questions_for_product_owner": ["..."]}
