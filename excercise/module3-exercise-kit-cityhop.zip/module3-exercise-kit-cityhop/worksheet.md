# CityHop Module 3 exercise worksheet

Name: ____________________   Tool and model used: ____________________

## Exercise 1: diagnose weak prompts
| Prompt | Missing or wrong part(s) | One fix |
|--------|--------------------------|---------|
| P1 | | |
| P2 | | |
| P3 | | |
| P4 | | |
| P5 | | |
My rewrite of P1: ______________________________________________

## Exercise 2: system or user?
1 ____ 2 ____ 3 ____ 4 ____ 5 ____ 6 ____ 7 ____ 8 ____

## Exercises 3 to 6 and 8: scores (out of 20)
| Exercise | Prompt | Run | AC | Boundaries | Questions | Format | Invention | Total |
|----------|--------|-----|----|------------|-----------|--------|-----------|-------|
| 3 | five parts | 1 | | | | | | |
| 3 | five parts | 2 | | | | | | |
| 4 | + few-shot | 1 | | | | | | |
| 4 | + few-shot | 2 | | | | | | |
| 5 | + step by step | 1 | | | | | | |
| 6 | Gherkin | 1 | | | | | | |
| 6 | checklist | 1 | | | | | | |
| 6 | JSON | 1 | | | | | | |
| 8 | template on US-CH-22 | 1 | | | | | | |

## Exercise 7: fix the failures
| Output | Main failure | One prompt change | Score before (script) |
|--------|--------------|-------------------|-----------------------|
| A | | | |
| B | | | |
| C | | | |
| D | | | |

## Exercise 9: regression set
Stories in my set: ______   When I rerun: ______   What I record: ______

## Exercise 10: self-check
Score: ____ / 10
