# Module 3 exercise kit: CityHop

Self-paced prompt engineering practice on the CityHop case study. Do the main Module 3 lab first.

- stories/          US-CH-21 (split the fare) and US-CH-22 (rate your driver)
- prompts/          template_v1.1_cityhop.txt
- prompts.md        weak prompts to diagnose, few-shot rows, step-by-step and format blocks
- data/flawed_outputs/  four AI answers with different failures (A to D)
- scoring/          rubric.md and answer_keys.json
- scripts/          score_answer.py (no AI needed) and run_prompt.py (optional, needs Azure)
- worksheet.md      record your answers

Instructions: Module3_Exercise_Manual_CityHop.docx
Answers: Module3_Exercise_Solutions_CityHop.docx (try first)

    cd scripts
    python score_answer.py ../data/flawed_outputs/A.md --story US-CH-21

Never commit scripts/.env. CityHop and everything in this kit is fictional.
