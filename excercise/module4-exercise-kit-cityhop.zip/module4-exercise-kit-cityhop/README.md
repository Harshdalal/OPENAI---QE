# Module 4 exercise kit: CityHop

Practice for Module 4 on a new case study. Do the main Module 4 lab first.
Instructions are in Module4_Exercise_Manual_CityHop.docx; answers in
Module4_Exercise_Solutions_CityHop.docx. CityHop is a fictional ride-hailing app.

| Folder | Exercise | Runs offline? |
|--------|----------|---------------|
| usecases/01_requirement_review | Find gaps in REQ-CH-30 (Ride Protect) | Playground prompt |
| usecases/02_test_data | Check AI-written fare test data in code | validate_fare_data.py: yes |
| usecases/03_failed_runs | Triage a nightly run; check a flawed AI release summary | summarize_run.py: yes, add --ask --mock |
| usecases/04_screenshots | Fare estimate screen: pixel diff and a vision model | diff_images.py: yes, add --ask --mock |
| usecases/05_copilot | Fare tests with GitHub Copilot, checked against a buggy copy | pytest: yes |
| usecases/06_rag | A knowledge assistant over the CityHop QE handbook | rag_demo.py --mock: yes |
| usecases/07_agent | Guardrails for a triage agent | Paper |
| canvas/ | Critique a weak canvas, then fill in your own | Paper or Word |

Setup (Python 3.10 or later):

    python -m pip install -r tools/requirements.txt
    copy tools\.env.example tools\.env          macOS or Linux: cp tools/.env.example tools/.env

Fill tools/.env with the Module 2 values to use a real model. Never commit .env.
Run each script from its own folder. All names, IDs and data in this kit are fictional.
