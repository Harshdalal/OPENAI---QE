# CityHop release process

## Go or no-go
The QE lead recommends go or no-go; the release manager decides. No release with an open S1. An open S2 needs written sign-off from the product owner, and any S2 that changes a fare blocks the release.

## Fare changes
Every change to fare rules F1 to F8 needs the agreed examples in fare_rules.md to pass, plus boundary tests for the changed rule, before release.

## Hotfixes
A hotfix needs one QE sign-off and the smoke suite. It goes to Staging first, never straight to production.
