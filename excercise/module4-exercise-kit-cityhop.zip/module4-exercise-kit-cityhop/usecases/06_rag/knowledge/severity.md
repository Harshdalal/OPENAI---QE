# CityHop defect severity and triage

## S1 Critical
Riders cannot book, pay or reach safety features, or fares are wrong for many riders. Triage within 1 hour, any time of day. A fix or rollback is needed before the next release.

## S2 Major
A feature is wrong for some riders and there is a workaround, for example a wrong fare in one time window. Triage within 1 working day.

## S3 Minor
Cosmetic issues and spelling mistakes that do not change a fare or a decision. Triage within 5 working days.
