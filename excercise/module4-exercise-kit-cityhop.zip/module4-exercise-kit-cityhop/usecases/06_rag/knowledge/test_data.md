# CityHop test data rules

## Test riders
Use the test riders rider01 to rider40, with emails at example.com. Test phone numbers are +91 90000 00001 to +91 90000 00040; OTPs to these numbers are always 123456 in QA.

## Payments
Test UPI ID for a successful payment: rider01@testbank. For a failed payment: fail@testbank. Test cards: 4111 1111 1111 1111 (success) and 5500 0000 0000 0004 (declined).

## Never
Never use a real rider's or driver's name, phone number, email, UPI ID or location history in a test, a prompt or a bug report. Never copy production data into QA.
