# CityHop test environments

Last reviewed: January 2026

## QA
Shared environment, redeployed every night at 01:45 IST. Use it for nightly regression and exploratory testing. Rider and driver test data is reset every Sunday.

## Staging
Production-like environment with masked production data. Use it for release candidates and load tests. Access needs a ticket to the platform team.

## Maps sandbox
maps-sandbox.test.cityhop.example. The QA key qa-maps-sandbox allows 2,000 calls per day and resets at 05:30 IST. Load tests must use their own key, never the QA key.

## Payment sandbox
payments-sandbox.test.cityhop.example. Payment callbacks can take up to 20 seconds in the sandbox. Planned maintenance is announced in the #qa-env channel at least 24 hours ahead.
