"""Use case 6 (CityHop exercise): a tiny knowledge assistant (RAG) over the CityHop QE handbook in knowledge/.

    python rag_demo.py --mock                          the five sample questions, offline
    python rag_demo.py                                 the five sample questions, real model
    python rag_demo.py --question "Which UPI ID do I use for a successful payment test?"

1. Split every document into sections.  2. Find the sections closest to the question
(embeddings, or word overlap in mock mode).  3. Send only those sections to the model and
ask it to answer from them, with citations, or say it does not know.
"""
import argparse
import math
import os
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "tools"))
from aiclient import get_client, model  # noqa: E402

QUESTIONS = [
    "Which UPI ID do I use for a successful payment test?",
    "How many calls per day does the QA maps key allow?",
    "Can we release with an open S2 bug that changes a fare?",
    "How fast must an S1 bug be triaged?",
    "What is the driver payout date this month?",
    "Can I use a real rider's phone number to test the OTP screen?",
]
INSTRUCTIONS = ("Answer the tester's question using only the sources between the <sources> tags. "
                "Cite every fact like [environments.md > Staging]. If the sources do not answer the question, "
                "reply exactly: I could not find this in the CityHop QE handbook. Keep answers to three sentences.")


def sections():
    out = []
    for path in sorted((HERE / "knowledge").glob("*.md")):
        for block in re.split(r"\n(?=## )", path.read_text(encoding="utf-8")):
            m = re.match(r"## (.+)\n", block)
            if m:
                out.append({"source": f"{path.name} > {m.group(1).strip()}", "text": block[m.end():].strip()})
    return out


def words(t):
    stop = {"the", "a", "an", "and", "or", "of", "to", "for", "in", "on", "is", "are", "be", "can", "we", "i", "do", "with", "what", "which", "how", "must", "should", "use"}
    return [w for w in re.findall(r"[a-z0-9]+", t.lower()) if w not in stop]


def cosine(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    return dot / ((math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b))) or 1)


def retrieve(client, question, secs, k=3):
    if client is None:  # mock: share of question words found in the section
        q = set(words(question))
        scored = [(len(q & set(words(s["source"] + " " + s["text"]))) / (len(q) or 1), s) for s in secs]
    else:
        emb = os.getenv("EMBEDDING_DEPLOYMENT", "qe-embed")
        vecs = client.embeddings.create(model=emb, input=[question] + [s["source"] + "\n" + s["text"] for s in secs]).data
        qv = vecs[0].embedding
        scored = [(cosine(qv, v.embedding), s) for v, s in zip(vecs[1:], secs)]
    return sorted(scored, key=lambda x: -x[0])[:k]


def mock_answer(question, hits):
    if not hits or hits[0][0] < 0.34:
        return "I could not find this in the CityHop QE handbook."
    top = hits[0][1]
    q = set(words(question))
    best = max(re.split(r"(?<=\.)\s", top["text"]), key=lambda sent: len(q & set(words(sent))))
    return f"{best} [{top['source']}]"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--question")
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    client = get_client(args.mock)
    secs = sections()
    print(f"Knowledge base: {len(secs)} sections from {len(list((HERE / 'knowledge').glob('*.md')))} documents.\n")
    for q in [args.question] if args.question else QUESTIONS:
        hits = retrieve(client, q, secs)
        print("=" * 70 + f"\nQ: {q}\nRetrieved:")
        for score, s in hits:
            print(f"  {score:.2f}  {s['source']}")
        if client is None:
            answer = mock_answer(q, hits)
        else:
            context = "\n\n".join(f"[{s['source']}]\n{s['text']}" for _, s in hits)
            answer = client.responses.create(model=model(), instructions=INSTRUCTIONS,
                                             input=f"<sources>\n{context}\n</sources>\n\nQuestion: {q}").output_text
        print(f"A: {answer}\n")
    print("Check one citation against the document. Grounded is not the same as correct if the document is out of date.")


if __name__ == "__main__":
    main()
