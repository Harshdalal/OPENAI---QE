"""Use case 3 (CityHop exercise): failed test run analysis and a release summary.

    python summarize_run.py                     digest only: no AI, no Azure
    python summarize_run.py --ask --mock        digest, then a practice AI analysis
    python summarize_run.py --ask               digest, then a real AI analysis

Step 1 is plain code: parse the JUnit XML, count results and group failures by signature.
Step 2 sends only that short digest and the log excerpt to the model, not the whole report.
"""
import argparse
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "tools"))
from aiclient import ask, get_client  # noqa: E402

INSTRUCTIONS = (
    "You are a QE lead at CityHop triaging a nightly test run. Use only the digest and the log excerpt. "
    "For each failure group, give: likely cause, category (product bug, test bug, environment, or flaky), "
    "evidence quoted from the input, and the next action with an owner role. Then write a release "
    "summary of at most 6 lines for a product manager: counts, risks, and a go or no-go recommendation "
    "with its condition. If the evidence is not enough, say so."
)

MOCK = """| Group | Tests | Likely cause | Category | Evidence | Next action |
|---|---|---|---|---|---|
| 1 | 3 maps ETA tests | Shared maps key ran out of quota during load test LT-55 | Environment | "load test LT-55 started on QA using the shared maps key" (ENV-812); "429 quota_exceeded" at 01:41 | Rerun after 05:30; ask for a separate key for load tests (QE, platform) |
| 2 | 2 night charge tests | Night window now includes hour 5; F4 says it ends at 04:59 | Product bug | build 2.9.0 "night window end inclusive: hour <= 5"; 05:00 gave 268, expected 223 | Raise a bug for the fare squad (dev) |
| 3 | test_upi_webhook_received | Slow payment callback, passed on retry | Flaky | "callback received after 15800 ms", then 2100 ms on retry | Track flakiness; check the 15 s timeout (QE) |
| 4 | test_receipt_shows_ride_date | Test computes the date in UTC; the ride is in IST | Test bug | "TZ=UTC", "datetime.utcnow()", ride start 00:20 IST | Fix the test to use the rider's time zone (QE) |

Release summary
42 tests: 34 passed, 7 failed, 1 skipped (split fare flag off).
One product bug: rides starting 05:00 to 05:59 are charged the night rate (fare rule F4).
Three maps failures came from a load test using the shared quota, not from the product.
One flaky payment callback test and one test bug in receipts.
Recommendation: no-go for fare build 2.9.0 until the night window is fixed; rerun maps tests after 05:30."""


def digest(xml_path):
    root = ET.parse(xml_path).getroot()
    counts = defaultdict(int)
    groups = defaultdict(list)
    for case in root.iter("testcase"):
        counts["total"] += 1
        fail = case.find("failure")
        if fail is None:
            fail = case.find("error")
        if case.find("skipped") is not None:
            counts["skipped"] += 1
        elif fail is not None:
            counts["failed"] += 1
            sig = f"{fail.get('type')}: " + re.sub(r"\d+", "N", fail.get("message", ""))[:90]
            detail = (fail.text or "").strip().splitlines()[-1]
            groups[sig].append((case.get("classname"), case.get("name"), detail))
        else:
            counts["passed"] += 1
    lines = [f"Run {root.get('name')} at {root.get('timestamp')}",
             f"Total {counts['total']}: passed {counts['passed']}, failed {counts['failed']}, skipped {counts['skipped']}",
             f"Failure groups: {len(groups)}"]
    for i, (sig, cases) in enumerate(sorted(groups.items(), key=lambda g: -len(g[1])), 1):
        lines.append(f"\nGroup {i} ({len(cases)} test{'' if len(cases) == 1 else 's'}): {sig}")
        for cls, name, detail in cases:
            lines.append(f"  - {cls}.{name}: {detail}")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xml", default=str(HERE / "junit_nightly_2026-11-06.xml"))
    ap.add_argument("--log", default=str(HERE / "app_log_excerpt.txt"))
    ap.add_argument("--ask", action="store_true", help="send the digest to the model")
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()

    text = digest(args.xml)
    print(text)
    full = Path(args.xml).stat().st_size
    print(f"\n(The digest is {len(text)} characters; the full report is {full}. Send the digest, not the report.)")
    if not args.ask:
        print("\nAdd --ask to have the model group causes and draft a release summary.")
        return
    log = Path(args.log).read_text(encoding="utf-8")
    client = get_client(args.mock)
    answer = ask(client, INSTRUCTIONS, f"<digest>\n{text}\n</digest>\n\n<log>\n{log}\n</log>", MOCK)
    print("\n" + "=" * 70 + "\n" + answer)
    print("\nCheck every cause against the evidence before it goes in a bug or a release note.")


if __name__ == "__main__":
    main()
