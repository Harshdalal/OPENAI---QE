# AI-drafted release summary: CityHop nightly run, 6 November 2026

This summary was drafted by an AI assistant from the nightly report. It has not been checked.
Find every statement that the digest and the log excerpt do not support.

---

**Results:** 42 tests: 36 passed, 6 failed.

**Product issues**
- The routing service is broken: three ETA tests failed with server errors. Bug BUG-4471 has
  already been raised with the maps squad.
- There is a payment outage: UPI callbacks are not arriving.

**Other failures**
- Two night charge tests failed because the test data is out of date after the fare change.
  Update the expected values to 268.
- One receipt test failed on the date; this is a known timing issue.

**Recommendation:** Go. The failures are in test data and third-party services, and fare
build 2.9.0 can be released tonight.
