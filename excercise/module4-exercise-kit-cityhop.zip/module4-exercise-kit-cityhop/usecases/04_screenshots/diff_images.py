"""Use case 4 (CityHop exercise): compare two screenshots pixel by pixel, then (optionally) ask a vision model.

    python diff_images.py                       pixel diff only, writes diff_overlay.png
    python diff_images.py --ask --mock          plus a practice vision-model answer
    python diff_images.py --ask                 plus a real vision-model answer

The pixel diff finds every change, including ones that do not matter (a countdown timer).
A vision model explains changes in words but can miss small ones. Use both, then decide.
"""
import argparse
import base64
import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "tools"))
from aiclient import get_client, model  # noqa: E402

CELL = 12  # pixels per grid cell when grouping changes into regions

PROMPT = ("Image 1 is the approved baseline of the CityHop fare estimate screen. Image 2 is the new build. "
          "List every visible difference, one per line, with: where it is, what changed, and whether it is "
          "a likely bug, an intended change, or dynamic content such as a timer. Do not guess at changes you cannot see.")

MOCK = """1. Header: "Driver in 4 min" now reads "Driver in 6 min". Dynamic content, not a bug.
2. Map: the car icon has moved along the route. Dynamic content, not a bug.
3. Fare card: the "1.3x surge" badge under the price is missing. Likely bug: riders must see surge before booking.
4. Confirm button: the label reads "Confirm rdie". Likely bug (spelling)."""


def regions(diff, threshold=30):
    """Group changed pixels into rectangles, using a coarse grid and flood fill."""
    gray = diff.convert("L").point(lambda v: 255 if v > threshold else 0)
    w, h = gray.size
    cols, rows = (w + CELL - 1) // CELL, (h + CELL - 1) // CELL
    hot = {(cx, cy) for cy in range(rows) for cx in range(cols)
           if gray.crop((cx * CELL, cy * CELL, min(w, (cx + 1) * CELL), min(h, (cy + 1) * CELL))).getbbox()}
    seen, boxes = set(), []
    for start in hot:
        if start in seen:
            continue
        stack, cells = [start], []
        seen.add(start)
        while stack:
            cx, cy = stack.pop()
            cells.append((cx, cy))
            for nx, ny in ((cx + dx, cy + dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1)):
                if (nx, ny) in hot and (nx, ny) not in seen:
                    seen.add((nx, ny))
                    stack.append((nx, ny))
        xs, ys = [c[0] for c in cells], [c[1] for c in cells]
        boxes.append((min(xs) * CELL, min(ys) * CELL, (max(xs) + 1) * CELL, (max(ys) + 1) * CELL))
    return sorted(boxes, key=lambda b: (b[1], b[0]))


def data_url(path):
    return "data:image/png;base64," + base64.b64encode(Path(path).read_bytes()).decode()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline", default=str(HERE / "baseline_fare_estimate.png"))
    ap.add_argument("--candidate", default=str(HERE / "candidate_fare_estimate.png"))
    ap.add_argument("--ask", action="store_true")
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()

    a = Image.open(args.baseline).convert("RGB")
    b = Image.open(args.candidate).convert("RGB")
    if a.size != b.size:
        sys.exit(f"Sizes differ: {a.size} and {b.size}. Capture both at the same size.")
    diff = ImageChops.difference(a, b)
    boxes = regions(diff)
    changed = sum(diff.convert("L").histogram()[31:])
    overlay = b.copy()
    draw = ImageDraw.Draw(overlay)
    for i, (x0, y0, x1, y1) in enumerate(boxes, 1):
        draw.rectangle([x0 - 2, y0 - 2, x1 + 2, y1 + 2], outline="#E53935", width=3)
        draw.text((x0, max(0, y0 - 14)), str(i), fill="#E53935")
    out = HERE / "diff_overlay.png"
    overlay.save(out)

    print(f"Pixel diff: {changed} pixels changed ({100 * changed / (a.width * a.height):.2f}% of the page), "
          f"in {len(boxes)} regions. Saved {out.name}.")
    for i, (x0, y0, x1, y1) in enumerate(boxes, 1):
        print(f"  {i}. x {x0}-{x1}, y {y0}-{y1}")
    print("The pixel diff cannot tell a bug from a timer. Open diff_overlay.png and decide for each region.")

    if not args.ask:
        print("\nAdd --ask to have a vision model describe the differences.")
        return
    client = get_client(args.mock)
    if client is None:
        answer = MOCK
    else:
        answer = client.responses.create(model=model(), input=[{"role": "user", "content": [
            {"type": "input_text", "text": PROMPT},
            {"type": "input_image", "image_url": data_url(args.baseline)},
            {"type": "input_image", "image_url": data_url(args.candidate)}]}]).output_text
    print("\n" + "=" * 70 + "\nVision model:\n" + answer)
    print("\nCompare the two lists. Which regions did the model not mention, and which did it explain better?")


if __name__ == "__main__":
    main()
