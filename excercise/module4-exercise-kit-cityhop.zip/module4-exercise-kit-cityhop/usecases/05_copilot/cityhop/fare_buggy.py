"""A broken copy of fare.py for practice. Do not fix it: your tests should catch it."""
from decimal import Decimal


def calculate_fare(distance_km, minutes, start_time, surge=1.0):
    if Decimal(str(distance_km)) < 0 or Decimal(str(minutes)) < 0:
        raise ValueError("distance and minutes must not be negative")
    km = Decimal(str(distance_km))
    distance = min(km, Decimal(10)) * 12 + max(Decimal(0), km - 10) * 9
    subtotal = max(Decimal(40) + distance + Decimal(str(minutes)) * Decimal("1.5"), Decimal(75))
    hour = int(start_time.split(":")[0])
    night = Decimal("1.2") if hour >= 23 or hour <= 5 else Decimal(1)
    surge = min(max(Decimal(str(surge)), Decimal(1)), Decimal(2))
    return round(subtotal * night * surge)
