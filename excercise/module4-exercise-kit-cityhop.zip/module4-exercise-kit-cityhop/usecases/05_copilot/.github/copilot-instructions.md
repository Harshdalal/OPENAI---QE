# Instructions for GitHub Copilot in this folder

- Tests use pytest. Put them in tests/, in files named test_*.py.
- Use pytest.mark.parametrize for boundary tables, with an id for every case.
- Take expected values from docs/fare_rules.md, never by calling or copying the code
  under test. If the rules do not say, write a TODO question instead of guessing.
- Fares are whole rupees; compare with integers.
- One behaviour per test. Test names say the rule, for example test_f4_night_ends_at_0459.
- No network calls, no sleeps, no real personal data.
