# Use case 5 (exercise): fare tests with GitHub Copilot

Open this folder (05_copilot) in VS Code with GitHub Copilot signed in with your company
account. Copilot reads .github/copilot-instructions.md automatically.

## Prompt 1 (Copilot Chat, Ask mode, with docs/fare_rules.md and cityhop/fare.py attached)

Write pytest tests for calculate_fare in tests/test_fare_rules.py. Take every expected value
from docs/fare_rules.md, not from the code. Cover each rule F1 to F8, and a value just
below, at and just above every boundary: the 10 km step, the night window start (23:00) and
end (04:59 and 05:00), the surge cap (2.0) and the minimum fare (75). Use parametrize with ids.

## Prompt 2 (follow-up)

Which rules or boundaries in docs/fare_rules.md do these tests not cover? Add tests for them,
or a TODO question if the rules do not say.

## Run

    python -m pytest tests                       should pass against cityhop/fare.py
    USE_BUGGY=1 python -m pytest tests           should fail: the buggy copy has three bugs

Windows cmd:   set USE_BUGGY=1 && python -m pytest tests
PowerShell:    $env:USE_BUGGY=1; python -m pytest tests

Then run the reference tests the same way and compare which bugs each set catches.
