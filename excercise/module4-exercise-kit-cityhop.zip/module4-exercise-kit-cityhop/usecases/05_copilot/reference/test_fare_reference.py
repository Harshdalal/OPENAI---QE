"""Reference tests written by hand from docs/fare_rules.md. Compare your Copilot tests with these.

Run:  python -m pytest reference            (passes)
      USE_BUGGY=1 python -m pytest reference (fails: the night, minimum and rounding tests catch the bugs)
"""
import pytest

from cityhop.fare import calculate_fare


@pytest.mark.parametrize(
    "km, minutes, start, surge, expected",
    [
        (5, 12, "14:00", 1.0, 118),
        (10, 20, "14:00", 1.0, 190),
        (11, 20, "14:00", 1.0, 199),
        (12, 30, "22:59", 1.0, 223),
        (12, 30, "23:00", 1.0, 268),
        (12, 30, "04:59", 1.0, 268),
        (12, 30, "05:00", 1.0, 223),
        (12, 30, "14:00", 2.0, 446),
        (12, 30, "14:00", 2.5, 446),
        (12, 30, "14:00", 1.5, 335),
        (1, 3, "14:00", 1.0, 75),
        (1, 3, "23:30", 1.0, 75),
        (12, 30, "23:30", 2.5, 535),
    ],
    ids=["ex1-day", "f2-at-10-km", "f2-11-km-step", "f4-2259-day", "f4-2300-night", "f4-0459-night",
         "f4-0500-day", "f5-at-cap", "f5-above-cap", "f8-half-up-334.5", "f7-minimum-day",
         "f7-minimum-after-night", "ex6-night-and-cap"],
)
def test_fare_by_rule(km, minutes, start, surge, expected):
    assert calculate_fare(km, minutes, start, surge) == expected


def test_negative_distance_raises():
    with pytest.raises(ValueError):
        calculate_fare(-1, 10, "14:00")
