"""Starter file. Ask GitHub Copilot to write tests here (see ../prompts.md)."""
from cityhop.fare import calculate_fare


def test_f1_to_f3_agreed_example_1():
    assert calculate_fare(5, 12, "14:00") == 118
