# REQ-CH-30: Ride Protect, a per-ride insurance add-on

Product: CityHop rider app (Android and iOS)
Owner: Rider safety squad
Status: Draft, for review

## Story

As a CityHop rider, I want to add accident cover to a ride, so that my medical costs are
covered if something goes wrong during the trip.

## Acceptance criteria

- AC1. Riders can add Ride Protect to a ride for INR 3.
- AC2. Ride Protect covers medical costs up to INR 2,00,000.
- AC3. Ride Protect is added automatically to every night ride.
- AC4. The Ride Protect charge is refunded if the ride is cancelled.
- AC5. The claim form should be simple to use.
- AC6. Riders must be 18 or over to buy Ride Protect.
- AC7. Ride Protect is always optional: the rider opts in at booking.
- AC8. The Ride Protect charge is added to the fare before surge is applied.

## Out of scope

Cover for drivers, and cover for luggage or personal items.
