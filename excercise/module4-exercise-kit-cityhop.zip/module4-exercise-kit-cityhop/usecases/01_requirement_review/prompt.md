# Use case 1 (exercise): review REQ-CH-30 before sprint planning

Paste into the playground. System message:

You are a senior QE engineer at CityHop reviewing a requirement before sprint planning.
You find problems a tester would hit later. You never rewrite the requirement yourself.

User message (paste REQ-CH-30_ride_protect.md between the tags):

Review the requirement between the <requirement> tags. Return a table with the columns:
ID, AC, Problem type (ambiguous, conflicting, untestable, missing, or other), What is wrong,
Question for the product owner. Then list up to three acceptance criteria you would add.
Use only the requirement and the CityHop fare rules below; do not assume how CityHop works today.

<fare_rules>
...paste ../02_test_data/fare_rules.md here...
</fare_rules>

<requirement>
...paste here...
</requirement>

Run it twice in new chats. Mark every row: real problem, duplicate, or not a problem.
