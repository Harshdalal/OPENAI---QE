# Proposal: a nightly triage agent for CityHop (paper exercise)

A squad lead wants an agent that runs at 03:00 IST after the nightly run and has these tools.
For each tool, decide: allow (read-only or harmless), allow with human approval, or do not give.
Then add the guardrails you would require before the first run.

| # | Tool the agent would get | What it does |
|---|--------------------------|--------------|
| T1 | read_junit | Reads the nightly JUnit XML |
| T2 | read_app_logs | Reads the QA app log for the run window |
| T3 | rerun_test | Reruns one failed test in QA |
| T4 | create_bug | Creates a bug in the tracker with a title, severity and evidence |
| T5 | update_expected_values | Edits expected values in the test code and commits to main |
| T6 | post_summary | Posts the release summary to the #release channel |
| T7 | rollback_deploy | Rolls back the latest QA deployment |
| T8 | read_prod_rider_data | Reads production rider records "to reproduce issues" |
| T9 | quarantine_test | Marks a test as flaky so it no longer fails the run |

Things to write down:

1. Your decision and reason for each tool.
2. Limits: how many reruns per test, per night?
3. What the agent must log for every action.
4. Where it runs first, and who reviews its output for the first two weeks.
