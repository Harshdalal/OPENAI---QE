"""Check AI-generated fare test data against the CityHop fare rules, in code.

    python validate_fare_data.py                          checks ai_generated_fare_data.csv
    python validate_fare_data.py my_data.csv

The model wrote expected_fare; this script recomputes every fare from fare_rules.md (F1 to F8)
and flags each row where they differ, plus any data that looks real.
"""
import csv
import re
import sys
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

SAFE_EMAIL = re.compile(r"^[\w.+-]+@example\.(com|org|net)$")


def rules_fare(distance_km, minutes, start_time, surge):
    """F1 to F8, written by hand from fare_rules.md. Returns (fare, notes)."""
    km = Decimal(distance_km)
    notes = []
    distance = min(km, Decimal(10)) * 12 + max(Decimal(0), km - 10) * 9            # F2
    subtotal = Decimal(40) + distance + Decimal(minutes) * Decimal("1.5")          # F1, F3
    hour = int(start_time.split(":")[0])
    night = hour >= 23 or hour < 5                                                 # F4
    if night:
        notes.append("night")
    s = Decimal(surge)
    if s > 2:
        notes.append(f"surge {surge} capped at 2.0")                              # F5
    s = min(max(s, Decimal(1)), Decimal(2))
    fare = subtotal * (Decimal("1.2") if night else 1) * s                        # F6
    raw = fare
    if fare < 75:
        notes.append("minimum fare")                                              # F7
        fare = Decimal(75)
    return int(fare.quantize(Decimal(1), rounding=ROUND_HALF_UP)), notes, raw      # F8


def check_row(r):
    problems = []
    fare, notes, exact = rules_fare(r["distance_km"], r["minutes"], r["start_time"], r["surge"])
    if int(r["expected_fare"]) != fare:
        why = f" ({', '.join(notes)})" if notes else ""
        problems.append(f"expected_fare is {r['expected_fare']}, rules give {fare}{why}; before minimum and rounding {exact.normalize():f}")
    if not SAFE_EMAIL.match(r["rider_email"]):
        problems.append(f"email {r['rider_email']} is not at example.com: it may be real personal data")
    if not r["trip_id"].startswith("TEST-"):
        problems.append("trip_id does not start with TEST-")
    return problems


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("ai_generated_fare_data.csv")
    with path.open(encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    bad = 0
    print(f"Checking {len(rows)} rows in {path.name}\n")
    for r in rows:
        problems = check_row(r)
        if problems:
            bad += 1
            print(f"{r['trip_id']}  ({r['purpose']})")
            for p in problems:
                print(f"   - {p}")
    print(f"\n{bad} of {len(rows)} rows have problems." if bad else "\nEvery row matches the rules.")
    print("Coverage is your job: the script checks values, not whether a boundary is missing.")
    print("Fix the prompt or the data, then run again. The rules, not the model, decide what is correct.")


if __name__ == "__main__":
    main()
