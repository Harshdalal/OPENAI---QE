# Use case 2 (exercise): fare test data

This is the prompt that produced ai_generated_fare_data.csv. Read it, then run
validate_fare_data.py to see what the model got wrong.

System message:
You are a QE engineer at CityHop. You write test data only from the rules you are given.

User message:
Using the fare rules between the <rules> tags, write 16 rows of CSV test data for the
fare calculator with the columns:
trip_id,rider_email,distance_km,minutes,start_time,surge,expected_fare,purpose
Cover every rule F1 to F8 and the boundaries of each: the 10 km step, the night window
start and end, the surge cap and the minimum fare. Use trip IDs starting TEST- and
emails at example.com only. Only output the CSV.

<rules>
...fare_rules.md...
</rules>
