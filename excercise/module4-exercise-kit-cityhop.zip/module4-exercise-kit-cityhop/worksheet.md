# Module 4 exercise worksheet: CityHop

Name: ____________________   Date: ____________

## Exercise 1. Requirement review (REQ-CH-30)

| AC | Problem type | What is wrong | Question for the product owner |
|----|--------------|---------------|--------------------------------|
|    |              |               |                                |

Real problems the model found: ___ of ___   Rows that were not real problems: ___

## Exercise 2. Fare test data

Rows the validator flagged: ___   Rule broken in each: ______________________
Boundary the data does not cover at all: ______________________

## Exercise 3. Failed run triage

| Group | Category (product, test, environment, flaky) | Evidence | Next action |
|-------|-----------------------------------------------|----------|-------------|
|       |                                               |          |             |

Errors in ai_release_summary_flawed.md: ______________________

## Exercise 4. Screenshot comparison

| Region | Bug, intended or dynamic? | Did the vision model mention it? |
|--------|---------------------------|----------------------------------|
|        |                           |                                  |

## Exercise 5. Copilot tests

Copilot tests: ___ passed on fare.py; ___ failed on fare_buggy.py
Bugs caught: night window [ ]   minimum fare after night [ ]   half-up rounding [ ]

## Exercise 6. Knowledge assistant

| Question | Answered, refused, or wrong? | Citation checked? |
|----------|------------------------------|-------------------|
|          |                              |                   |

## Exercise 7. Agent guardrails

| Tool | Allow, approval, or do not give | Why |
|------|---------------------------------|-----|
|      |                                 |     |

## Exercise 8. Value of a use case

Minutes today per day: ___   Minutes with AI including the human check: ___
Working days per month: ___   Hours saved per month: ___

## Exercise 9. Canvas

Five weaknesses in weak_canvas_cityhop.md: ______________________
My use case and first step: ______________________
