# A weak AI Use-Case Canvas (critique this one)

Team: CityHop rider support QE (fictional)

| Field | What the team wrote |
|-------|---------------------|
| 1. Team and task | Use AI for all of our testing. |
| 2. Pain today | Testing is slow. |
| 3. Who uses the output | Everyone. |
| 4. Inputs and sensitivity | Last month's rider complaints exported from production, with names, phone numbers and pickup addresses. |
| 5. AI pattern | Generate. |
| 6. Tool | Whatever free chatbot is fastest. |
| 7. First prompt or template | "Find all the bugs in these complaints." |
| 8. Human check | Not needed; the AI is accurate. |
| 9. Success measure | Better quality. |
| 10. Risks and guardrails | None. |
| 11. Value and effort | High value, small effort. |
| 12. First step | Start next quarter. |
