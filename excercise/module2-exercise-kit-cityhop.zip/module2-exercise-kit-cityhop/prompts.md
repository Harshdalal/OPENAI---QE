# CityHop Module 2 exercise prompts

## Exercise 3: playground

System message:

You are a QE assistant. Write test scenarios from the requirement the user gives you. Use
only that requirement. If something is missing, list it under "Questions for the product owner".

User message (paste REQ-CH-12_schedule_ride.md between the tags):

Write test scenarios for the requirement between the <requirement> tags as a table with the
columns: ID, title, type (positive, negative or boundary), AC, expected result. Include
boundary scenarios just below, at and just above every number in the requirement.

<requirement>
...paste here...
</requirement>

## Exercise 4: agent

Instructions: agent/agent_instructions.md, then fare_rules.md and REQ-CH-12 below them.
Test cases: agent/agent_test_cases.md

## Exercise 9a: image review in the playground

Attach data/schedule_ride_screen.png and send:

Today is Saturday 07 November 2026, 10:00. Review this Schedule a ride screen against the
requirement below. List every place where the screen breaks an acceptance criterion, one
line each, with the AC number. Do not report anything you cannot see.

(paste REQ-CH-12_schedule_ride.md here)
