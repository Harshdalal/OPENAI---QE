# Module 2 exercise kit: CityHop

Self-paced practice for Module 2 on the CityHop case study. Do the main Module 2 lab first.

- requirements/   REQ-CH-12 (schedule a ride) and the fare rules
- data/           rider messages, support tickets, a screen to review, a fictional invoice
- agent/          instructions and test cases for the cityhop-fare-assistant agent
- scripts/        fare.py and 01 to 05 (every script accepts --mock)
- prompts.md      portal prompts      worksheet.md   record your answers

Instructions: Module2_Exercise_Manual_CityHop.docx
Answers: Module2_Exercise_Solutions_CityHop.docx (try first)

    cd scripts
    python -m pip install -r requirements.txt
    python fare.py
    python 02_extract_requests.py --mock
    copy .env.example .env          macOS or Linux: cp .env.example .env

Never commit .env. CityHop and all names, IDs and amounts in this kit are fictional.
