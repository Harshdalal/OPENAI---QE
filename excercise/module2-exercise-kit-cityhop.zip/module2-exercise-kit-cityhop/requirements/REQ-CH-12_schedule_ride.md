# REQ-CH-12: Schedule a ride in advance

Product: CityHop rider app (fictional)
Status: Ready for test

## Story

As a CityHop rider, I want to book a ride for a later time, so that I can plan airport
trips and early starts.

## Acceptance criteria

- AC1. A ride can be scheduled from 30 minutes to 7 days ahead of the current time.
- AC2. Pickup times are offered in 15-minute steps, for example 09:00, 09:15, 09:30.
- AC3. Ride types are Mini, Sedan and SUV. Mini and Sedan seat up to 4 riders; SUV seats
  up to 6.
- AC4. The app shows an estimated fare using the CityHop fare rules F1 to F8 with a surge
  of 1.0. The final fare may differ.
- AC5. Cancellation is free up to 60 minutes before pickup. After that, the cancellation
  fee is INR 50.
- AC6. The rider gets a reminder notification 30 minutes before pickup.
- AC7. A rider can have at most 3 scheduled rides at a time.

## Out of scope

Recurring rides, rides for other people, and corporate accounts.
