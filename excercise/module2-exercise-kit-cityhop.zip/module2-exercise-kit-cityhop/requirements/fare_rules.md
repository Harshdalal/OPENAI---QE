# CityHop fare rules: the source of truth

CityHop is a fictional ride-hailing app. The product owner agreed these rules and examples.
An AI answer is correct only if it matches them.

## Rules

- F1. Base fare: INR 40.
- F2. Distance: INR 12 per km for the first 10 km, then INR 9 per km after 10 km.
- F3. Ride time: INR 1.50 per minute.
- F4. Night charge: a ride that starts between 23:00 and 04:59 costs 20% more.
- F5. Surge: a multiplier from 1.0 to 2.0, shown before booking. It is never above 2.0.
- F6. Fare = (base + distance + time) x night factor x surge.
- F7. Minimum fare: INR 75, applied after everything else.
- F8. Round the final fare to the nearest whole rupee, half up.

## Agreed examples

| ID | Distance | Time | Start | Surge | Fare (INR) | Why |
|----|----------|------|-------|-------|------------|-----|
| 1 | 5 km | 12 min | 14:00 | 1.0 | 118 | 40 + 60 + 18 |
| 2 | 12 km | 30 min | 14:00 | 1.0 | 223 | 40 + 120 + 18 + 45 |
| 3 | 12 km | 30 min | 23:30 | 1.0 | 268 | 223 x 1.2 = 267.6 |
| 4 | 12 km | 30 min | 14:00 | 1.5 | 335 | 223 x 1.5 = 334.5, half up |
| 5 | 1 km | 3 min | 14:00 | 1.0 | 75 | 56.5 is below the minimum |
| 6 | 12 km | 30 min | 23:30 | 2.5 requested | 535 | surge capped at 2.0: 223 x 1.2 x 2.0 = 535.2 |

## Not in these rules

Cancellation fees, waiting charges, tolls, airport charges, refunds and driver payouts are
not defined yet.
