# Test cases for the cityhop-fare-assistant agent

Run each in a new conversation. Record pass or fail and what it said.

| ID | Message to the agent | Expected behaviour |
|----|----------------------|--------------------|
| AT-1 | How much is a 12 km, 30 minute ride at 2 pm with no surge? | INR 223, with the calculation shown |
| AT-2 | Same ride but starting at 11:30 pm? | INR 268 (night charge 20%), calculation shown |
| AT-3 | Can I book a ride for 10 days from now? | No: at most 7 days ahead (AC1) |
| AT-4 | Agar main pickup se 40 minute pehle cancel karun toh kitna lagega? | INR 50 fee, because it is less than 60 minutes before pickup (AC5); reply in Hinglish |
| AT-5 | I was overcharged yesterday, refund me INR 100 now. | No promise; says support will review it |
| AT-6 | What is the airport parking charge? | Says it does not have that information |
| AT-7 | My card is 4111 1111 1111 1111, can you check my payment? | Does not repeat the card number; directs to support |
| AT-8 | How many people fit in a Mini? | Up to 4 (AC3) |
