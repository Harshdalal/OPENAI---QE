"""CityHop fare rules F1 to F8 in code (see requirements/fare_rules.md)."""
from decimal import ROUND_HALF_UP, Decimal


def calculate_fare(distance_km, minutes, start_time, surge=1.0):
    """Return the fare in whole rupees. start_time is 'HH:MM'."""
    km = Decimal(str(distance_km))
    distance = min(km, Decimal(10)) * 12 + max(Decimal(0), km - 10) * 9          # F2
    subtotal = Decimal(40) + distance + Decimal(str(minutes)) * Decimal("1.5")   # F1, F3
    hour = int(start_time.split(":")[0])
    night = Decimal("1.2") if hour >= 23 or hour < 5 else Decimal(1)              # F4
    surge = min(max(Decimal(str(surge)), Decimal(1)), Decimal(2))                 # F5
    fare = max(subtotal * night * surge, Decimal(75))                             # F6, F7
    return int(fare.quantize(Decimal(1), rounding=ROUND_HALF_UP))                 # F8


if __name__ == "__main__":
    for args, expected in [((5, 12, "14:00"), 118), ((12, 30, "14:00"), 223), ((12, 30, "23:30"), 268),
                           ((12, 30, "14:00", 1.5), 335), ((1, 3, "14:00"), 75), ((12, 30, "23:30", 2.5), 535)]:
        got = calculate_fare(*args)
        print(f"{args} -> {got}  {'ok' if got == expected else 'EXPECTED ' + str(expected)}")
