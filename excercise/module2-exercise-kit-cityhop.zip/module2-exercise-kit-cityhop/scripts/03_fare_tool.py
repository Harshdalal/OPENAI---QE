"""Exercise 7: tool calling. The model asks your code to calculate the fare, instead of doing the maths.

    python 03_fare_tool.py --mock
    python 03_fare_tool.py
    python 03_fare_tool.py --question "Which is cheaper: 12 km in 30 min at 23:30, or 14 km in 25 min at 14:00?"
"""
import argparse
import json

from aiclient import get_client, model
from fare import calculate_fare

TOOLS = [{
    "type": "function", "name": "calculate_fare", "strict": True,
    "description": "Calculate a CityHop fare in whole rupees using fare rules F1 to F8.",
    "parameters": {"type": "object", "additionalProperties": False,
                   "required": ["distance_km", "minutes", "start_time", "surge"],
                   "properties": {"distance_km": {"type": "number"}, "minutes": {"type": "number"},
                                  "start_time": {"type": "string", "description": "HH:MM, 24-hour"},
                                  "surge": {"type": "number", "description": "1.0 if not given"}}},
}]
DEFAULT_Q = "How much is an 18 km ride of 41 minutes starting at 14:00 with a surge of 1.3?"


class _Call:
    def __init__(self, i, args):
        self.type, self.name, self.call_id, self.arguments = "function_call", "calculate_fare", f"call_{i}", json.dumps(args)


def mock_calls(question):
    if "cheaper" in question.lower():
        return [_Call(1, {"distance_km": 12, "minutes": 30, "start_time": "23:30", "surge": 1.0}),
                _Call(2, {"distance_km": 14, "minutes": 25, "start_time": "14:00", "surge": 1.0})]
    return [_Call(1, {"distance_km": 18, "minutes": 41, "start_time": "14:00", "surge": 1.3})]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--question", default=DEFAULT_Q)
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    client = get_client(args.mock)
    print(f"You: {args.question}\n")
    if client is None:
        calls = mock_calls(args.question)
    else:
        first = client.responses.create(model=model(), input=args.question, tools=TOOLS)
        calls = [i for i in first.output if getattr(i, "type", "") == "function_call"]
        if not calls:
            print("The model answered without the tool (check its maths!):\n" + first.output_text)
            return
    outputs = []
    for c in calls:
        a = json.loads(c.arguments)
        fare = calculate_fare(a["distance_km"], a["minutes"], a["start_time"], a["surge"])
        print(f"Model asked: calculate_fare({a}) -> your code returned INR {fare}")
        outputs.append({"type": "function_call_output", "call_id": c.call_id, "output": json.dumps({"fare_inr": fare})})
    if client is None:
        fares = [json.loads(o["output"])["fare_inr"] for o in outputs]
        answer = (f"The fare is INR {fares[0]}." if len(fares) == 1 else
                  f"The first ride costs INR {fares[0]} and the second INR {fares[1]}, so the "
                  f"{'first' if fares[0] < fares[1] else 'second'} is cheaper.")
    else:
        answer = client.responses.create(model=model(), previous_response_id=first.id, input=outputs, tools=TOOLS).output_text
    print("\nAI: " + answer)
    print("\nThe number came from your code, not from the model's arithmetic.")


if __name__ == "__main__":
    main()
