"""Exercise 5: a small chat client for the CityHop fare assistant (OpenAI SDK + Foundry deployment).

    python 01_chat.py --mock      practice run
    python 01_chat.py             real run (reads scripts/.env)

Your task: change SYSTEM below, then ask two questions where the second depends on the first.
"""
import sys
from pathlib import Path

from aiclient import get_client, model

KIT = Path(__file__).resolve().parents[1]
SYSTEM = ("You are the CityHop fare assistant. Use only these fare rules. Show the calculation in one line.\n\n"
          + (KIT / "requirements" / "fare_rules.md").read_text(encoding="utf-8"))


def main():
    mock = "--mock" in sys.argv
    client = get_client(mock)
    previous, turn = None, 0
    print("Ask about CityHop fares. Type 'exit' to stop.\n")
    while True:
        try:
            q = input("You: ").strip()
        except EOFError:
            break
        if q.lower() in ("", "exit", "quit"):
            break
        turn += 1
        if client is None:
            print(f"\nAI: (mock answer {turn}) In a real run the model answers here, using the fare rules."
                  f"\n   [tokens in {600 + 80 * turn}, out 40]\n")
            continue
        extra = {"previous_response_id": previous} if previous else {}
        r = client.responses.create(model=model(), instructions=SYSTEM, input=q, **extra)
        previous = r.id
        print(f"\nAI: {r.output_text}\n   [tokens in {r.usage.input_tokens}, out {r.usage.output_tokens}]\n")


if __name__ == "__main__":
    main()
