"""Exercise 9a: multimodal input. Review the Schedule a ride screen against REQ-CH-12.

    python 05_review_screenshot.py --mock
    python 05_review_screenshot.py        (the deployment must accept images; check its model card)
"""
import base64
import sys
from pathlib import Path

from aiclient import get_client, model

KIT = Path(__file__).resolve().parents[1]
MOCK = """1. Pickup time 09:10 is not a 15-minute step (AC2).
2. Mini shows 6 seats; Mini seats up to 4 (AC3).
3. Free cancellation up to 30 min; REQ-CH-12 says 60 minutes (AC5).
4. Reminder 15 min before pickup; REQ-CH-12 says 30 minutes (AC6)."""


def main():
    client = get_client("--mock" in sys.argv)
    req = (KIT / "requirements" / "REQ-CH-12_schedule_ride.md").read_text(encoding="utf-8")
    img = "data:image/png;base64," + base64.b64encode((KIT / "data" / "schedule_ride_screen.png").read_bytes()).decode()
    prompt = ("Today is Saturday 07 November 2026, 10:00. Review this Schedule a ride screen against the requirement below. "
              "List every place where the screen breaks an acceptance criterion, one line each, with the AC number. "
              "Do not report anything you cannot see.\n\n" + req)
    if client is None:
        answer = MOCK
    else:
        answer = client.responses.create(model=model(), input=[{"role": "user", "content": [
            {"type": "input_text", "text": prompt}, {"type": "input_image", "image_url": img}]}]).output_text
    print(answer)
    print("\nCompare with the solutions. Did it miss one, or report something that is fine?")


if __name__ == "__main__":
    main()
