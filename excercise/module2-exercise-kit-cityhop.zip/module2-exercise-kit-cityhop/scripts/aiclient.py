"""Shared helper for the CityHop Module 2 exercise scripts: reads scripts/.env and returns a client, or None in mock mode."""
import os
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent


def load_env():
    path = TOOLS / ".env"
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def get_client(mock):
    """Return an OpenAI client for your Foundry deployment, or None when mock is True."""
    load_env()
    if mock:
        print("MOCK MODE: AI answers are invented by the script, not by a model.\n")
        return None
    try:
        from openai import OpenAI
    except ImportError:
        sys.exit("The openai package is missing. Run: python -m pip install -r scripts/requirements.txt")
    if not os.getenv("OPENAI_BASE_URL"):
        sys.exit("Missing OPENAI_BASE_URL in scripts/.env. Copy scripts/.env.example to scripts/.env, or add --mock.")
    if os.getenv("AUTH", "key").lower() == "entra":
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        token = get_bearer_token_provider(DefaultAzureCredential(), "https://ai.azure.com/.default")
        return OpenAI(base_url=os.environ["OPENAI_BASE_URL"], api_key=token)
    if not os.getenv("OPENAI_API_KEY"):
        sys.exit("Missing OPENAI_API_KEY in scripts/.env (or set AUTH=entra and run az login).")
    return OpenAI(base_url=os.environ["OPENAI_BASE_URL"], api_key=os.environ["OPENAI_API_KEY"])


def model():
    return os.getenv("MODEL_DEPLOYMENT", "qe-chat")


def ask(client, instructions, text, mock_answer):
    """One call to the Responses API. In mock mode, return mock_answer instead."""
    if client is None:
        return mock_answer
    return client.responses.create(model=model(), instructions=instructions, input=text).output_text
