"""Exercise 8: embeddings. Find duplicate support tickets and route new tickets to the closest existing one.

    python 04_similar_tickets.py --mock
    python 04_similar_tickets.py
    python 04_similar_tickets.py --threshold 0.5
"""
import argparse
import hashlib
import math
import os
import re
from pathlib import Path

from aiclient import get_client

KIT = Path(__file__).resolve().parents[1]
# crude stand-in for meaning in mock mode only; real embeddings do this far better
CONCEPTS = {"twice": "dup", "two": "dup", "double": "dup", "debits": "dup", "charged": "charge", "deducted": "charge", "debit": "charge",
            "longer": "route", "different": "route", "way": "route", "map": "route", "route": "route",
            "crashes": "crash", "closes": "crash", "rate": "rating", "rating": "rating",
            "scheduled": "sched", "booked": "sched", "pre": "sched", "never": "noshow", "show": "noshow", "assigned": "noshow", "cancelled": "noshow",
            "refund": "refund", "waiting": "refund", "promised": "refund"}


def read(name):
    rows = [l.split("|", 1) for l in (KIT / "data" / name).read_text(encoding="utf-8").splitlines() if "|" in l]
    return [r[0].strip() for r in rows], [r[1].strip() for r in rows]


def mock_vec(text):
    v = [0.0] * 128
    for w in re.findall(r"[a-z]+", text.lower()):
        if len(w) > 2 or w in ("pre",):
            w = CONCEPTS.get(w, w)
            v[int(hashlib.md5(w.encode()).hexdigest(), 16) % 128] += 1
    n = math.sqrt(sum(x * x for x in v)) or 1
    return [x / n for x in v]


def cos(a, b):
    return sum(x * y for x, y in zip(a, b)) / ((math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b))) or 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float)
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    client = get_client(args.mock)
    ids, texts = read("support_tickets.txt")
    nids, ntexts = read("new_tickets.txt")
    if client is None:
        vecs = [mock_vec(t) for t in texts + ntexts]
        thr = args.threshold if args.threshold is not None else 0.45
    else:
        res = client.embeddings.create(model=os.getenv("EMBEDDING_DEPLOYMENT", "qe-embed"), input=texts + ntexts)
        vecs = [d.embedding for d in res.data]
        thr = args.threshold if args.threshold is not None else 0.6
    old, new = vecs[:len(texts)], vecs[len(texts):]
    pairs = sorted(((cos(old[i], old[j]), i, j) for i in range(len(old)) for j in range(i + 1, len(old))), reverse=True)
    print(f"Likely duplicates among {len(ids)} tickets (similarity {thr:.2f} or more):")
    for s, i, j in pairs:
        if s < thr:
            break
        print(f"  {s:.2f}  {ids[i]} <-> {ids[j]}")
    print("\nNew tickets, closest existing ticket:")
    for k, v in enumerate(new):
        best = max(range(len(old)), key=lambda i: cos(v, old[i]))
        print(f"  {nids[k]} -> {ids[best]} ({cos(v, old[best]):.2f})  \"{texts[best][:60]}\"")
    print("\nA person confirms each duplicate before tickets are merged.")


if __name__ == "__main__":
    main()
