"""Exercise 6: turn free-text rider messages into structured booking requests, then check REQ-CH-12 in code.

    python 02_extract_requests.py --mock
    python 02_extract_requests.py

The model only extracts (strict JSON schema). Python decides whether each booking is valid.
Your task in the manual: add a "luggage_bags" field to the schema and rerun.
"""
import json
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

from aiclient import get_client, model
from fare import calculate_fare  # noqa: F401  (used in the optional task)

KIT = Path(__file__).resolve().parents[1]
NOW = datetime(2026, 11, 7, 10, 0)            # the messages arrived on Sat 07 Nov 2026 at 10:00
SEATS = {"Mini": 4, "Sedan": 4, "SUV": 6}

ITEM = {
    "type": "object", "additionalProperties": False,
    "required": ["id", "request_type", "pickup", "drop", "date", "time", "ride_type", "passengers"],
    "properties": {
        "id": {"type": "string"},
        "request_type": {"type": "string", "enum": ["booking", "cancellation", "other"]},
        "pickup": {"type": ["string", "null"]},
        "drop": {"type": ["string", "null"]},
        "date": {"type": ["string", "null"], "description": "YYYY-MM-DD"},
        "time": {"type": ["string", "null"], "description": "HH:MM, 24-hour"},
        "ride_type": {"type": ["string", "null"], "enum": ["Mini", "Sedan", "SUV", "unsupported", None]},
        "passengers": {"type": ["integer", "null"]},
    },
}
SCHEMA = {"type": "object", "additionalProperties": False, "required": ["requests"],
          "properties": {"requests": {"type": "array", "items": ITEM}}}

INSTRUCTIONS = (f"Today is {NOW:%A %d %B %Y} and the time is {NOW:%H:%M}. Extract one request per message. "
                "Resolve words like tomorrow, kal, today and 'in 45 minutes' into a date and a 24-hour time. "
                "Copy what the rider asked for; do not correct it. Use 'unsupported' for a ride type CityHop does not offer, "
                "and null for anything the message does not say. Messages may be in Hinglish.")

MOCK = {"requests": [
    {"id": "R1", "request_type": "booking", "pickup": "Koramangala", "drop": "Airport", "date": "2026-11-08", "time": "05:30", "ride_type": "Sedan", "passengers": None},
    {"id": "R2", "request_type": "booking", "pickup": "Whitefield", "drop": "Mysore Road", "date": "2026-11-14", "time": "09:00", "ride_type": "SUV", "passengers": 6},
    {"id": "R3", "request_type": "booking", "pickup": "HSR Layout", "drop": "MG Road", "date": "2026-11-08", "time": "07:10", "ride_type": "Mini", "passengers": None},
    {"id": "R4", "request_type": "booking", "pickup": "Jayanagar", "drop": "Hebbal", "date": "2026-11-07", "time": "10:15", "ride_type": "Mini", "passengers": 5},
    {"id": "R5", "request_type": "booking", "pickup": "Indiranagar", "drop": "Electronic City", "date": "2026-11-20", "time": "18:00", "ride_type": "Sedan", "passengers": None},
    {"id": "R6", "request_type": "booking", "pickup": "MG Road", "drop": "Airport", "date": "2026-11-07", "time": "10:45", "ride_type": "Sedan", "passengers": None},
    {"id": "R7", "request_type": "booking", "pickup": "Yeshwanthpur", "drop": "Hebbal", "date": "2026-11-08", "time": "12:00", "ride_type": "unsupported", "passengers": None},
    {"id": "R8", "request_type": "cancellation", "pickup": None, "drop": "Airport", "date": None, "time": "05:30", "ride_type": None, "passengers": None}]}


def check(req):
    """REQ-CH-12 rules, in code. Returns a list of problems."""
    if req["request_type"] != "booking":
        return [f"not a booking ({req['request_type']}): route to support"]
    problems = []
    if not req["date"] or not req["time"]:
        return ["date or time missing: ask the rider"]
    when = datetime.strptime(f"{req['date']} {req['time']}", "%Y-%m-%d %H:%M")
    ahead = when - NOW
    if ahead < timedelta(minutes=30):
        problems.append(f"AC1: only {int(ahead.total_seconds() // 60)} minutes ahead (minimum 30)")
    if ahead > timedelta(days=7):
        problems.append(f"AC1: {ahead.days} days ahead (maximum 7)")
    if when.minute % 15:
        problems.append(f"AC2: {req['time']} is not a 15-minute step")
    rt = req["ride_type"]
    if rt not in SEATS:
        problems.append(f"AC3: ride type {rt!r} is not offered")
    elif (req["passengers"] or 1) > SEATS[rt]:
        problems.append(f"AC3: {req['passengers']} riders do not fit in a {rt} (max {SEATS[rt]})")
    return problems


def main():
    mock = "--mock" in sys.argv
    lines = [l for l in (KIT / "data" / "rider_requests.txt").read_text(encoding="utf-8").splitlines() if "|" in l]
    client = get_client(mock)
    if client is None:
        data = MOCK
    else:
        r = client.responses.create(model=model(), instructions=INSTRUCTIONS, input="\n".join(lines),
                                    text={"format": {"type": "json_schema", "name": "booking_requests", "schema": SCHEMA, "strict": True}})
        data = json.loads(r.output_text)
    print(f"{'ID':<4}{'type':<14}{'date':<12}{'time':<7}{'ride':<12}{'pax':<5}result")
    for req in data["requests"]:
        problems = check(req)
        print(f"{req['id']:<4}{req['request_type']:<14}{str(req['date']):<12}{str(req['time']):<7}{str(req['ride_type']):<12}"
              f"{str(req['passengers']):<5}{'VALID' if not problems else 'REJECT'}")
        for p in problems:
            print(f"      - {p}")
    print("\nThe model extracted; the code decided. Compare each row with the message before you trust it.")


if __name__ == "__main__":
    main()
