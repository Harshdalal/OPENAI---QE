# CityHop Module 2 exercise worksheet

Name: ____________________   Deployments used: ____________________

## Exercise 1: which offering?
a ______  b ______  c ______  d ______  e ______  f ______

## Exercise 2: model card and plan
Model and version: ______   Inputs: ______   Context window: ______
Structured outputs / tool calling: ______   Deployment types: ______   Retirement date: ______
Plan: deployment name ______  type ______  tokens per minute ______

## Exercise 3: playground and View code
ACs covered: ______   Boundaries missing: ______   Invented: ______
Endpoint: ______   Deployment name in code: ______   Auth: ______   API: ______

## Exercise 4: agent test cases
| Test | v1 pass/fail | v2 pass/fail | Notes |
|------|--------------|--------------|-------|
| AT-1 | | | |
| AT-2 | | | |
| AT-3 | | | |
| AT-4 | | | |
| AT-5 | | | |
| AT-6 | | | |
| AT-7 | | | |
| AT-8 | | | |

## Exercise 5: chat client
Turn 1 tokens in ______  Turn 2 tokens in ______  Why did turn 2 work? ______

## Exercise 6: structured outputs
| Msg | Your expected result | Script result | Same? |
|-----|----------------------|---------------|-------|
| R1 | | | |
| R2 | | | |
| R3 | | | |
| R4 | | | |
| R5 | | | |
| R6 | | | |
| R7 | | | |
| R8 | | | |
luggage_bags for messages without luggage: ______

## Exercise 7: tool calling
Default answer: INR ______   Comparison: ride 1 INR ______  ride 2 INR ______
Surge passed when not given: ______

## Exercise 8: embeddings
Your groups: ____________________
Pairs missed by the script: ______   False pairs: ______   N-1 -> ______  N-2 -> ______

## Exercise 9: multimodal and Content Understanding
9a. Breaks you found: ______   The model found: ______   False alarms: ______
9b. Invoice no ______ date ______ vendor ______ subtotal ______ GST ______ total ______
Arithmetic correct? ______   Missing fields for CityHop: ______

## Exercise 10: privacy and access
| # | Problem | Fix |
|---|---------|-----|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |

## Exercise 11: self-check
Score: ____ / 10
