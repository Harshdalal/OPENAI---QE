<!-- AI OUTPUT 5 of 7
Prompt: "Summarise REQ-CH-41 for the test team in five bullets."
Source: inputs/REQ-CH-41_driver_tips.md -->

# REQ-CH-41 summary

- Riders can tip for up to 48 hours after the ride.
- Preset tips are INR 10, 20 and 50; custom tips go up to INR 500.
- CityHop keeps a 10% service fee on every tip; the rest goes to the driver.
- Tips can be paid by UPI, card or CityHop Wallet.
- Riders can edit a tip within 1 hour of paying it. Tips are tax-deductible for riders.
