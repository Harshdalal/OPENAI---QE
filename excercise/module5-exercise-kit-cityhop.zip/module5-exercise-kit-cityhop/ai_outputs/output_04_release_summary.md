<!-- AI OUTPUT 4 of 7
Prompt: "Write a release summary for fare build 2.9.1 from the nightly digest."
Source: inputs/nightly_run_digest.txt -->

# Release summary: fare build 2.9.1

**Status: GO**

- 42 of 44 tests passed.
- The failures were all flaky and passed on retry.
- Surge pricing was verified on every boundary, including the 2.0 cap.
- Ride Protect is now live for all riders.
- Fare calculation is 25% faster than build 2.9.0.
- No open S1 or S2 bugs.
