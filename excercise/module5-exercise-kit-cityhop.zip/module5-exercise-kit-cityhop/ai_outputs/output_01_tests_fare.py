# AI OUTPUT 1 of 7
# Prompt: "Write pytest tests for calculate_fare in cityhop/fare.py."
# The assistant's note: "These tests cover every fare rule F1 to F8."
from cityhop.fare import calculate_fare


def test_day_fare_example():
    assert calculate_fare(5, 12, "14:00") == 118


def test_over_10_km():
    expected = calculate_fare(12, 30, "14:00")
    assert calculate_fare(12, 30, "14:00") == expected


def test_night_fare():
    # 223 x 1.2 = 267.6
    assert calculate_fare(12, 30, "23:30") == 267


def test_surge_applied():
    assert calculate_fare(12, 30, "14:00", surge=2.5) > 223


def test_minimum_fare():
    fare = calculate_fare(1, 3, "14:00")


def test_fare_is_positive():
    assert calculate_fare(8, 20, "10:00") >= 0


def test_night_window_edges():
    try:
        assert calculate_fare(12, 30, "22:59") == 223
        assert calculate_fare(12, 30, "05:00") == 223
    except AssertionError:
        pass
