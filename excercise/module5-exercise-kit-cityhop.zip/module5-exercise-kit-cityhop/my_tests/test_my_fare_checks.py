"""Exercise 3: write tests here that pass on cityhop/fare.py and fail on cityhop/fare_buggy.py.
Take every expected value from docs/fare_rules.md, never from the code."""
from cityhop.fare import calculate_fare


def test_agreed_example_1():
    assert calculate_fare(5, 12, "14:00") == 118
