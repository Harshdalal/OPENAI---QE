"""A broken copy of fare.py for practice. Do not fix it: good tests should catch it."""
from decimal import ROUND_HALF_UP, Decimal


def calculate_fare(distance_km, minutes, start_time, surge=1.0):
    if Decimal(str(distance_km)) < 0 or Decimal(str(minutes)) < 0:
        raise ValueError("distance and minutes must not be negative")
    km = Decimal(str(distance_km))
    distance = min(km, Decimal(11)) * 12 + max(Decimal(0), km - 11) * 9
    subtotal = Decimal(40) + distance + Decimal(str(minutes)) * Decimal("1.5")
    hour = int(start_time.split(":")[0])
    night = Decimal("1.2") if hour >= 22 or hour < 5 else Decimal(1)
    surge = max(Decimal(str(surge)), Decimal(1))
    fare = max(subtotal * night * surge, Decimal(75))
    return int(fare.quantize(Decimal(1), rounding=ROUND_HALF_UP))
