"""CityHop fare rules F1 to F8 in code (see docs/fare_rules.md)."""
from decimal import ROUND_HALF_UP, Decimal


def calculate_fare(distance_km, minutes, start_time, surge=1.0):
    """Return the fare in whole rupees. start_time is 'HH:MM' (24-hour)."""
    if Decimal(str(distance_km)) < 0 or Decimal(str(minutes)) < 0:
        raise ValueError("distance and minutes must not be negative")
    km = Decimal(str(distance_km))
    distance = min(km, Decimal(10)) * 12 + max(Decimal(0), km - 10) * 9          # F2
    subtotal = Decimal(40) + distance + Decimal(str(minutes)) * Decimal("1.5")   # F1, F3
    hour = int(start_time.split(":")[0])
    night = Decimal("1.2") if hour >= 23 or hour < 5 else Decimal(1)              # F4
    surge = min(max(Decimal(str(surge)), Decimal(1)), Decimal(2))                 # F5
    fare = max(subtotal * night * surge, Decimal(75))                             # F6, F7
    return int(fare.quantize(Decimal(1), rounding=ROUND_HALF_UP))                 # F8
