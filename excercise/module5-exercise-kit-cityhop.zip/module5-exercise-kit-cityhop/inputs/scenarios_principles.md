# Exercise 1: which responsible AI principle? (paper)

For each CityHop situation, name the principle most at stake (fairness, reliability and
safety, privacy and security, inclusiveness, transparency, accountability) and one QE check.

1. The new AI support bot understands English well but often misreads riders who write in Kannada or Hinglish.
2. A release note drafted by AI is published under the test lead's name; nobody checked it.
3. AI-written regression tests are merged without a label; months later nobody knows which tests came from AI.
4. The AI fare explainer gives a different total each time a rider asks the same question.
5. A tester pastes a rider's complaint, with phone number and pickup address, into a free chatbot.
6. The voice booking feature does not work with a screen reader.
7. The AI pickup-point suggester sends riders in some neighbourhoods to a pickup point 800 m away, and riders elsewhere to the door.
8. A squad lead says: "The agent raised the bug, so the agent is responsible if it is wrong."
