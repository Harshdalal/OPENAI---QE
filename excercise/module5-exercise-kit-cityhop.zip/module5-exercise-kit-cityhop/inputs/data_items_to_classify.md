# Exercise 2: may this go into the tool? (paper)

Three tools: (A) a free personal chatbot account, (B) GitHub Copilot Business with your
company account, (C) CityHop's own Foundry deployment, approved for internal and masked data.
For each item, mark which tools may see it: none, C only, B and C, or all three.

1. The public CityHop fare rules from the help centre
2. fare.py from the CityHop repository
3. A nightly JUnit digest with TEST- IDs only
4. Rider complaints exported from production, with names and phone numbers
5. The same complaints after masking names, phones, UPI IDs and addresses
6. The production pricing API key
7. REQ-CH-41 (internal draft requirement)
8. A screenshot of the fare estimate screen with a test rider's UPI ID rider01@testbank
