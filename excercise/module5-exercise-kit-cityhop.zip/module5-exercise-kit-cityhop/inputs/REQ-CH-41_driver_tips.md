# REQ-CH-41: Tip your driver

Product: CityHop rider app
Owner: Driver experience squad

## Acceptance criteria

- AC1. A rider can add a tip after a completed ride, for up to 24 hours after the ride ends.
- AC2. Tip amounts: INR 10, 20 or 50, or a custom amount from INR 1 to INR 200.
- AC3. 100% of the tip goes to the driver. CityHop takes no commission on tips.
- AC4. Tips can be paid by UPI or card only, not cash or CityHop Wallet.
- AC5. A tip cannot be changed or refunded once it is paid.
- AC6. The tip appears on the ride receipt as a separate line.
- AC7. Cancelled rides cannot receive a tip.
