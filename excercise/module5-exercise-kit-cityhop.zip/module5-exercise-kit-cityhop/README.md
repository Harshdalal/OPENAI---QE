# Module 5 exercise kit: CityHop

Practice for Module 5 on a new case study. Do the main Module 5 activity first.
Instructions are in Module5_Exercise_Manual_CityHop.docx; answers in
Module5_Exercise_Solutions_CityHop.docx. CityHop is a fictional ride-hailing app.

Seven outputs an AI assistant produced for the CityHop QE team. Every one has mistakes.

- ai_outputs/output_01_tests_fare.py        tests for cityhop/fare.py (rules: docs/fare_rules.md)
- ai_outputs/output_02_test_riders.csv      test riders for the fare and payment tests
- ai_outputs/output_03_booking_ui_test.py   an end-to-end booking test (read it, do not run it)
- ai_outputs/output_04_release_summary.md   from inputs/nightly_run_digest.txt
- ai_outputs/output_05_requirement_summary.md from inputs/REQ-CH-41_driver_tips.md
- ai_outputs/output_06_feedback_triage.md   from inputs/rider_feedback_for_triage.md
- ai_outputs/output_07_chat_transcript.md   a tester's chat with a personal chatbot

Paper exercises: inputs/scenarios_principles.md and inputs/data_items_to_classify.md.

Tools (Python 3.10 or later), run from this folder:

    python -m pip install -r tools/requirements.txt
    python -m pytest ai_outputs/output_01_tests_fare.py -q
    USE_BUGGY=1 python -m pytest ai_outputs/output_01_tests_fare.py -q
        (PowerShell: $env:USE_BUGGY=1; python -m pytest ai_outputs/output_01_tests_fare.py -q)
    python tools/scan_secrets_pii.py
    python -m bandit -r ai_outputs -s B101
    python tools/injection_demo.py --mock

All names, numbers, keys and passwords in this kit are fictional; the AWS key is AWS's own
documentation example.
