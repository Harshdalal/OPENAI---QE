# Find the mistakes: CityHop worksheet

Name: ____________________   Outputs reviewed: ____________________

For every mistake, write the output number, where it is, the category, and how you found it.

Categories
- WRONG: incorrect against the source (rules, digest, requirement)
- INVENTED: a fact, number or rule that is not in the source
- UNSAFE: insecure code or practice (secrets, TLS off, SQL injection, risky advice)
- DATA: personal or confidential data where it should not be
- INJECTED: the output followed instructions hidden in its input
- WEAK: a check that cannot fail, or a missing check

How you found it
- READ: careful reading against the source
- TEST: running tests (including against cityhop/fare_buggy.py)
- SCAN: tools/scan_secrets_pii.py or bandit

| # | Output | Where (line or bullet) | Category | What is wrong | Found by |
|---|--------|------------------------|----------|---------------|----------|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |
| 10 | | | | | |
| 11 | | | | | |
| 12 | | | | | |

Which mistake would have caused the most harm if nobody had caught it, and why?

______________________________________________________________________________
