"""Lets you run the same tests against the broken implementation:

    USE_BUGGY=1 python -m pytest tests          (macOS or Linux)
    set USE_BUGGY=1 && python -m pytest tests   (Windows cmd)
    $env:USE_BUGGY=1; python -m pytest tests    (PowerShell)
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

if os.getenv("USE_BUGGY") == "1":
    import cityhop.fare_buggy as buggy

    sys.modules["cityhop.fare"] = buggy
    print("\n*** Running against cityhop/fare_buggy.py ***")
